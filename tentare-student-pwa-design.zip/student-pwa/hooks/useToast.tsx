'use client';
import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';
type Ctx = { toast: (msg: string) => void };
const C = createContext<Ctx>({ toast: () => {} });
export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null);
  const t = useRef<ReturnType<typeof setTimeout>>();
  const toast = useCallback((m: string) => { clearTimeout(t.current); setMsg(m); t.current = setTimeout(() => setMsg(null), 2300); }, []);
  return (
    <C.Provider value={{ toast }}>
      {children}
      {msg && (
        <div role="status" aria-live="polite" style={{ position: 'fixed', top: 'calc(14px + var(--safe-top))', left: 16, right: 16, zIndex: 95, display: 'flex', justifyContent: 'center', pointerEvents: 'none' }}>
          <div style={{ background: 'var(--primary)', color: 'var(--primary-foreground)', borderRadius: 999, padding: '10px 18px', fontSize: 12.5, fontWeight: 700, boxShadow: 'var(--shadow-toast)', animation: 'apToast .35s var(--ease-spring) both' }}>{msg}</div>
        </div>
      )}
    </C.Provider>
  );
}
export const useToast = () => useContext(C);
