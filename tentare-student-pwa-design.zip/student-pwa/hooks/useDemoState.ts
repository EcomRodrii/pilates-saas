'use client';
import { useSearchParams } from 'next/navigation';
import type { ViewState } from '@/types';
/**
 * SOLO PARA REVISIÓN DEL DISEÑO: ?state=loading|empty|error|offline fuerza el
 * estado de una vista. Claude Code puede eliminarlo o dejarlo tras un flag.
 */
export function useDemoState(): ViewState | null {
  const sp = useSearchParams();
  const s = sp.get('state');
  return s === 'loading' || s === 'empty' || s === 'error' || s === 'offline' ? s : null;
}
