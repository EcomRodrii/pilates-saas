'use client';
import { useEffect, useState } from 'react';
/** Estado de conexión + "reconectando" 1.5 s tras volver. */
export function useOnline() {
  const [online, setOnline] = useState(true);
  const [reconectando, setRec] = useState(false);
  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => { setOnline(true); setRec(true); setTimeout(() => setRec(false), 1500); };
    const off = () => setOnline(false);
    window.addEventListener('online', on); window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  return { online, reconectando };
}
