'use client';
import { useEffect, useState } from 'react';
import type { ViewState } from '@/types';
import { useOnline } from './useOnline';
import { useDemoState } from './useDemoState';
/** Carga datos y deriva el ViewState (loading/ready/empty/error/offline). */
export function useAsync<T>(fn: () => Promise<T>, vacio: (d: T) => boolean = (d) => Array.isArray(d) && d.length === 0) {
  const [data, setData] = useState<T | null>(null);
  const [estado, setEstado] = useState<ViewState>('loading');
  const [tick, setTick] = useState(0);
  const { online } = useOnline();
  const demo = useDemoState();
  useEffect(() => {
    let vivo = true; setEstado('loading');
    fn().then((d) => { if (!vivo) return; setData(d); setEstado(vacio(d) ? 'empty' : 'ready'); }).catch(() => vivo && setEstado('error'));
    return () => { vivo = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick]);
  const final: ViewState = demo ?? (!online && estado !== 'ready' ? 'offline' : estado);
  return { data, estado: final, reintentar: () => setTick((t) => t + 1) };
}
