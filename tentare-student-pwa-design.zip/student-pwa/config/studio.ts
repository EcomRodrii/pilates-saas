// Configuración white-label del estudio. En producción la sirve el backend
// (por slug/dominio). Claude Code: sustituir este objeto por el fetch real,
// manteniendo la forma de StudioConfig.
import type { StudioConfig } from '@/types';

export const studio: StudioConfig = {
  slug: 'studio-alma',
  nombre: 'Studio Alma',
  ciudad: 'Barcelona',
  direccion: 'C/ Verdi 42, Gràcia',
  logoUrl: null,                 // null → se usa el monograma con las iniciales
  iconoUrl: '/icons/icon-192.png',
  fotoPortada: '/assets/foto-reformer.webp',
  telefono: '+34 600 000 000',
  email: 'hola@studioalma.es',
  disciplinas: ['Pilates', 'Yoga'],
  politicaCancelacionHoras: 12,
  soportaListaEspera: true,
  tema: {
    // Sobrescriben las variables de styles/tokens.css. Vacío = tema por defecto.
    // Ejemplo estudio con marca terracota:
    // '--accent': '#B5573F', '--accent-soft': '#F6E7E1', '--accent-soft-foreground': '#7A3A2A', '--accent-deep': '#3B1F17'
  },
};
