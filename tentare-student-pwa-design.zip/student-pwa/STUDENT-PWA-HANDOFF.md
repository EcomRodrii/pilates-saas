# STUDENT-PWA-HANDOFF

## A. Screen Inventory
| # | Pantalla | Fichero |
|---|---|---|
| 1 | Login | app/(auth)/login/page.tsx |
| 2 | Registro | app/(auth)/registro/page.tsx |
| 3 | Recuperar contraseña (form + enviado) | app/(auth)/recuperar-password/page.tsx |
| 4 | Verificar email (OTP 4 dígitos) | app/(auth)/verificar-email/page.tsx |
| 5 | Inicio (hero, próxima clase, bono, huecos) | app/(app)/page.tsx |
| 6 | Reservar / Horario (días + filtros + lista) | app/(app)/reservar/page.tsx |
| 7 | Detalle de clase + sheet de reserva | app/(app)/reservar/[classId]/page.tsx |
| 8 | Confirmación por URL | app/(app)/reservar/confirmacion/page.tsx |
| 9 | Mis clases (próximas / historial + cancelar) | app/(app)/mis-reservas/page.tsx |
| 10 | Detalle de reserva + pase QR | app/(app)/mis-reservas/[bookingId]/page.tsx |
| 11 | Calendario mensual | app/(app)/calendario/page.tsx |
| 12 | Bonos | app/(app)/bonos/page.tsx |
| 13 | Detalle de bono | app/(app)/bonos/[creditId]/page.tsx |
| 14 | Pagos | app/(app)/pagos/page.tsx |
| 15 | Recibo | app/(app)/pagos/[paymentId]/page.tsx |
| 16 | Notificaciones | app/(app)/notificaciones/page.tsx |
| 17 | Perfil | app/(app)/perfil/page.tsx |
| 18 | Datos personales | app/(app)/perfil/datos/page.tsx |
| 19 | Preferencias | app/(app)/perfil/preferencias/page.tsx |
| 20 | Ayuda | app/(app)/ayuda/page.tsx |
| 21 | Offline (fallback SW) | app/offline/page.tsx |

## B. Route Mapping
`/` Inicio · `/reservar` · `/reservar/[classId]` · `/reservar/confirmacion?state=` · `/mis-reservas` · `/mis-reservas/[bookingId]` · `/calendario` · `/bonos` · `/bonos/[creditId]` · `/pagos` · `/pagos/[paymentId]` · `/notificaciones` · `/perfil` · `/perfil/datos` · `/perfil/preferencias` · `/ayuda` · `/login` · `/registro` · `/recuperar-password` · `/verificar-email` · `/offline`.
Nav inferior: Inicio · Reservar · Mis clases · Bonos · Perfil. Calendario, Pagos, Notificaciones, Ayuda son secundarias (accesibles desde header/Reservar/Perfil).

## C. Component Inventory
| Componente | Usado en |
|---|---|
| AppShell | layout (app) |
| StudioHeader | AppShell |
| BottomNavigation | AppShell |
| PageHeader | todas las vistas (app) salvo Inicio y detalle de clase (hero propio) |
| OfflineBanner | AppShell (sticky bajo header) |
| NextClassCard | Inicio |
| ClassCard | Inicio, Reservar, Calendario |
| InstructorCard | Detalle de clase |
| CreditCard | Inicio (compacta), Bonos, Detalle bono |
| BookingButton | Detalle de clase (CTA persistente) |
| BookingSummary | Sheet de reserva |
| BookingStatus | Sheet de reserva, Confirmación |
| ConfirmationDialog | Cancelar reserva, Cerrar sesión |
| Sheet | ConfirmationDialog, sheet de reserva |
| EmptyState / ErrorState / OfflineState / Skeleton / ListSkeleton | todas las listas |
| NotificationItem | Notificaciones |
| PaymentItem | Pagos |
| ProfileSection | Perfil, Ayuda |
| Calendar | Calendario |
| DateSelector | Reservar |
| Toast (useToast) | acciones secundarias (calendario, cómo llegar, guardado) |
| Button / Badge (AvailabilityBadge) / Input | global |

## D. State Inventory
Todas las listas: loading (skeleton) · ready · empty (EmptyState con acción) · error (ErrorState + reintentar) · offline (OfflineState si no hay datos; banner si los hay).
- Inicio: + sin próxima clase · sin bono activo · sin huecos hoy.
- Reservar: + sin clases ese día · filtro sin resultados (acción quitar filtro).
- Detalle clase: disponible · pocas (≤2) · completa→lista de espera · no-disponible (si el estudio no soporta espera) · reservada · en lista · offline (CTA bloqueado) · clase no encontrada.
- Mis clases: próximas/historial · en espera (posición) · cancelable dentro/fuera de plazo · cancelando (botón loading) · cancelación fallida (toast, reserva intacta) · cancelada.
- Bonos: activo · pocas sesiones · sin sesiones · agotado · expirado · sin bonos.
- Pagos: success · processing · failed (CTA reintentar) · cancelled · refunded.
- Notificaciones: no leída (fondo accent-soft + dot) · leída · vacío.
- Auth: campo inválido (aria-invalid + mensaje) · error global de credenciales · loading · éxito (recuperar) · OTP incorrecto · sin conexión (CTA bloqueado).
- Perfil/Datos: validación · guardando · sin conexión.

## E. Responsive Rules
- 320–430: una columna; `.px` 18px; nav 5 tabs con label 9.5px; CTA detalle fijo sobre la nav; sheets a ancho completo.
- 320 específico: DateSelector y filtros hacen scroll horizontal; ClassCard trunca nombre con ellipsis; badges nowrap.
- ≥768: shell 640px; auth en dos columnas (foto | formulario); `.px` 24px; sheets max 640 centrados.
- ≥1024: shell 1040px; `.grid-lg-2` divide detalle de clase, reserva, bono, inicio y perfil en dos columnas; nav inferior se mantiene.
- Listas largas: scroll natural; skeleton de 3–4 ítems; nunca alturas fijas. Banner offline sticky no tapa el título (PageHeader tiene su propio padding).

## F. White-label Rules
Cambia por estudio: nombre, ciudad, dirección, logo (o monograma), icono PWA, foto de portada, fotos de clases, teléfono/email, disciplinas, política de cancelación (horas), soporte de lista de espera y las variables de `tema` (`--primary*`, `--accent*`, `--background`, `--card`, `--border`, `--font-sans`). NO cambia: escala tipográfica, radios, sombras, motion, estructura.

## G. Booking State Machine
`idle → reviewing → submitting → { confirmed | waitlisted | full | conflict | duplicate | session-expired | error }`; `reviewing → offline` si no hay red al confirmar.
- **idle**: CTA según disponibilidad (BookingButton).
- **reviewing**: sheet con BookingSummary (bono o precio, política) + CTA "Confirmar".
- **submitting**: CTA con spinner y texto "Un momento…"; sheet no se puede cerrar; texto "Confirmando con el estudio…".
- **confirmed**: check 64px + anillo + 6 confetis; título "Reserva confirmada"; CTA "Ver mis reservas". ÚNICO estado con celebración.
- **waitlisted**: icono "!" ámbar; CTA "Ver mis reservas".
- **full**: "Se ha llenado mientras reservabas"; CTAs "Unirme a la lista de espera" / "Volver al horario".
- **conflict**: "Ya tienes una clase a esa hora"; CTA volver.
- **duplicate**: "Ya estabas apuntada"; CTA volver.
- **session-expired**: CTA "Iniciar sesión" → /login.
- **offline**: "Sin conexión… no se ha hecho ningún cargo"; CTA reintentar (vuelve a reviewing).
- **error**: "Algo no ha salido como esperábamos… no se ha usado ninguna sesión"; CTA reintentar.
Copy exacto en `lib/booking-machine.ts → COPY`. Transiciones válidas en `TRANSICIONES`.

## H. Offline Rules
Visible offline (última caché): Inicio, Horario, Mis clases, Bonos, Pagos, Perfil, Ayuda. Bloqueado offline (botón disabled + texto "Sin conexión"): reservar, unirse a lista, cancelar, guardar datos, login. Banner sticky "Sin conexión — puedes consultar, pero no reservar ni pagar"; al volver, banner verde "Conexión recuperada · actualizando" 1.5 s. Nunca se muestra éxito de reserva/cancelación/pago sin respuesta del servidor. SW: solo GET; POST nunca se cachea.

## I. Animation Inventory
- Entrada de pantalla: `apFade .25s`; bloques `apUp .4s` escalonados 55 ms por ítem (listas) o 60 ms por bloque (hero).
- Cards: `.card--tap` active scale(.98), hover sombra `--shadow-card`.
- Botones: active scale(.97); loading spinner `apSpin .7s`.
- Sheets: translateY(110%→0) .38s `--ease-spring`; velo fade .3s; arrastre del handle cierra a >90px.
- Segmented (Mis clases): píldora deslizante .32s spring.
- Confirmación: `apCheck .55s` + `apRing .9s` + confetis `apConfA/B/C .95s`; textos `apUp` a 150/220/300 ms.
- Badges "pocas plazas": dot `apPulse 2.2s`. Notificación sin leer: dot `apDot .4s`.
- Hero: `apKen 18–22s` (Ken Burns) en fotos de portada.
- Toast: `apToast .35s` spring, 2.3 s. Banner offline: `apSlideDown .35s`.
- Toggle: knob translateX .25s spring. Calendar: cambio de mes sin animación (rápido).
- `prefers-reduced-motion`: todo desactivado.

## J. Assets Inventory
public/assets: foto-reformer.webp (portada/Reformer), foto-clase.webp, foto-estudio.webp, foto-hero.jpg (Yoga), foto-pilates.jpg (instructora). public/icons: icon-192.png, icon-512.png, icon-maskable-512.png. public/manifest.webmanifest, public/sw.js. Fuentes por next/font/google. Iconos de nav: SVG inline (paths en BottomNavigation.tsx).

## K. Implementation Notes
1. Ejecutar `scripts/rename-routes.mjs` antes del primer `dev`.
2. Implementar `lib/data/index.ts` con las MISMAS firmas; `confirmarReserva` debe devolver el estado real del servidor (mapear 409 → conflict/duplicate/full, 401 → session-expired).
3. `useAsync` deriva ViewState; mantenerlo o sustituir por React Query respetando los 5 estados.
4. `config/studio.ts` → cargar por slug/dominio en el layout raíz y pasar a `aplicarTema`.
5. Registrar `sw.js` (o el plugin PWA del repo) en el layout raíz; `manifest` debe generarse por estudio (nombre/iconos).
6. Sesión: si el adaptador devuelve 401 en cualquier vista → redirigir a `/login` conservando `?next=`.
7. QR: sustituir el grid decorativo por el QR real (token de acceso rotativo).
8. Eliminar o gatear `useDemoState` y `?outcome` en producción.
9. Accesibilidad ya aplicada: roles tab/switch/dialog, aria-pressed, aria-invalid + describedby, aria-live en toasts y resultados, touch targets ≥44px, focus-visible con `--accent`.

## L. Do Not Change
Paleta y tokens (styles/tokens.css) · tipografía Plus Jakarta Sans 800 en titulares y IBM Plex Mono en etiquetas/horas · radios 16/20/24/999 · sombras neutras · nav inferior (iconos, 9.5px/800) · hero fotográfico con gradiente a crema · card "Tu próxima clase" verde noche · badges de disponibilidad (colores y textos) · sheet de reserva y celebración · copy de estados de reserva · estructura de estados vacíos con acción.
