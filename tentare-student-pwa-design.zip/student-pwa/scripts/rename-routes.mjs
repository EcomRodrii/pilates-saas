// Los ZIP no conservan bien carpetas con ( ) y [ ]. Este script renombra
// -app- → (app), -auth- → (auth), -id- → [id]. Ejecutar UNA vez: node scripts/rename-routes.mjs
import { readdirSync, renameSync, statSync } from 'node:fs';
import { join } from 'node:path';
const MAP = { '-app-': '(app)', '-auth-': '(auth)', '-classId-': '[classId]', '-bookingId-': '[bookingId]', '-creditId-': '[creditId]', '-paymentId-': '[paymentId]' };
function walk(dir) { for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) { walk(p); if (MAP[n]) renameSync(p, join(dir, MAP[n])); } } }
walk('app'); console.log('Rutas renombradas. Ya puedes: npm run dev');
