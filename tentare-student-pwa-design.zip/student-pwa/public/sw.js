// Service worker MÍNIMO de referencia (network-first + fallback /offline).
// Claude Code: sustituir por next-pwa/serwist si el repo ya lo usa. Nunca cachear
// respuestas de reserva/cancelación/pago (POST) — solo lectura.
const CACHE = 'student-pwa-v1';
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(['/offline']))); self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).then((r) => { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); return r; }).catch(() => caches.match(e.request).then((r) => r || (e.request.mode === 'navigate' ? caches.match('/offline') : Response.error()))));
});
