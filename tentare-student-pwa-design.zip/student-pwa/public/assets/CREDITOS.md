# Fotografías
Fotos de referencia del prototipo (Pilates/Yoga, estudio, instructoras). Sustituir por las fotos reales de cada estudio (white-label): `config/studio.ts → fotoPortada` y `Clase.fotoUrl`.
