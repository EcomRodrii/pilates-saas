'use client';
import { useEffect, useRef, useState, type ReactNode } from 'react';
/** Bottom sheet del kit: handle 34×4, radius 24, spring, cierra con velo, Esc y arrastre. */
export function Sheet({ open, onClose, children, label }: { open: boolean; onClose: () => void; children: ReactNode; label: string }) {
  const [dy, setDy] = useState(0); const y0 = useRef<number | null>(null);
  useEffect(() => { if (!open) return; const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); document.addEventListener('keydown', k); return () => document.removeEventListener('keydown', k); }, [open, onClose]);
  useEffect(() => { if (!open) setDy(0); }, [open]);
  return (
    <>
      <div onClick={onClose} aria-hidden style={{ position: 'fixed', inset: 0, zIndex: 50, background: 'rgba(15,15,15,.42)', opacity: open ? 1 : 0, pointerEvents: open ? 'auto' : 'none', transition: 'opacity .3s' }} />
      <div role="dialog" aria-modal aria-label={label}
        style={{ position: 'fixed', left: 0, right: 0, bottom: 0, zIndex: 51, maxWidth: 640, margin: '0 auto', background: 'var(--background)', borderRadius: 'var(--radius-sheet) var(--radius-sheet) 0 0', boxShadow: 'var(--shadow-sheet)', paddingBottom: 'var(--safe-bottom)', transform: open ? 'translateY(' + dy + 'px)' : 'translateY(110%)', transition: y0.current !== null ? 'none' : 'transform var(--dur-sheet) var(--ease-spring)' }}>
        <div onPointerDown={(e) => { y0.current = e.clientY; }} onPointerMove={(e) => { if (y0.current !== null) setDy(Math.max(0, e.clientY - y0.current)); }} onPointerUp={() => { if (dy > 90) onClose(); y0.current = null; setDy(0); }}
          style={{ padding: '9px 0 4px', touchAction: 'none', cursor: 'grab' }}><div style={{ width: 34, height: 4, borderRadius: 99, background: 'var(--border-strong)', margin: '0 auto' }} /></div>
        <div style={{ padding: '10px 18px 26px' }}>{children}</div>
      </div>
    </>
  );
}
