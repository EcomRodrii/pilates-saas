import type { ButtonHTMLAttributes, ReactNode } from 'react';
type V = 'primary' | 'secondary' | 'ghost' | 'danger' | 'light';
export function Button({ variant = 'primary', size, full, loading, children, className = '', ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: V; size?: 'sm'; full?: boolean; loading?: boolean; children: ReactNode }) {
  return (
    <button type="button" {...rest} disabled={rest.disabled || loading} aria-busy={loading || undefined}
      className={['btn', 'btn--' + variant, size ? 'btn--' + size : '', full ? 'btn--full' : '', className].join(' ')}>
      {loading && <span aria-hidden style={{ width: 14, height: 14, border: '2px solid currentColor', borderRightColor: 'transparent', borderRadius: 99, animation: 'apSpin .7s linear infinite' }} />}
      {loading ? 'Un momento…' : children}
    </button>
  );
}
