'use client';
import Link from 'next/link';
import type { Clase, Disponibilidad, Instructora } from '@/types';
import { AvailabilityBadge } from '@/components/ui/Badge';
import { euros } from '@/lib/format';
/** Fila de clase del horario (kit): hora mono | divisor | nombre + avatar instructora | badge + precio. */
export function ClassCard({ clase, instructora, estado, conBono, delay = 0 }: { clase: Clase; instructora?: Instructora; estado: Disponibilidad; conBono: boolean; delay?: number }) {
  return (
    <Link href={'/reservar/' + clase.id} className="card card--tap a-up" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', animationDelay: delay + 'ms', borderColor: estado === 'reservada' ? 'var(--accent)' : undefined, borderWidth: estado === 'reservada' ? 1.5 : 1 }}>
      <div style={{ textAlign: 'center', minWidth: 46 }}>
        <p className="t-mono" style={{ margin: 0, fontSize: 14, fontWeight: 500 }}>{clase.hora}</p>
        <p style={{ margin: '1px 0 0', fontSize: 9.5, color: 'var(--subtle-foreground)' }}>{clase.duracionMin} min</p>
      </div>
      <div aria-hidden style={{ width: 1, alignSelf: 'stretch', background: 'var(--muted)' }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontSize: 13.5, fontWeight: 800, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{clase.nombre}</p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
          <span aria-hidden style={{ width: 20, height: 20, borderRadius: 999, flexShrink: 0, background: instructora?.fotoUrl ? 'url(' + instructora.fotoUrl + ') center/cover' : 'var(--accent-soft)', color: 'var(--accent-soft-foreground)', fontSize: 8.5, fontWeight: 800, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>{!instructora?.fotoUrl && instructora?.iniciales}</span>
          <p className="t-meta" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{instructora?.nombre ?? '—'} · {clase.sala}</p>
        </div>
      </div>
      <div style={{ textAlign: 'right', flexShrink: 0 }}>
        <AvailabilityBadge estado={estado} plazas={clase.plazasLibres} />
        <p style={{ margin: '5px 0 0', fontSize: 11.5, fontWeight: 800, color: 'var(--muted-foreground)' }}>{conBono ? '1 sesión' : euros(clase.precioSuelto)}</p>
      </div>
    </Link>
  );
}
