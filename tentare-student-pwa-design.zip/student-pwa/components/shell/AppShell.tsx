'use client';
import { useEffect, type ReactNode } from 'react';
import { studio } from '@/config/studio';
import { aplicarTema } from '@/lib/theme';
import { ToastProvider } from '@/hooks/useToast';
import { StudioHeader } from './StudioHeader';
import { BottomNavigation } from './BottomNavigation';
import { OfflineBanner } from './OfflineBanner';
/** Marco de toda pantalla autenticada: header fijo, banner offline, contenido, nav inferior. */
export function AppShell({ children, noLeidas = 2, badgeReservas = 1, headerTransparente = false }: { children: ReactNode; noLeidas?: number; badgeReservas?: number; headerTransparente?: boolean }) {
  useEffect(() => { aplicarTema(studio.tema); }, []);
  return (
    <ToastProvider>
      <div className="shell">
        <StudioHeader noLeidas={noLeidas} transparente={headerTransparente} />
        <main className="page" style={headerTransparente ? { paddingTop: 0 } : undefined}>
          <OfflineBanner />
          {children}
        </main>
        <BottomNavigation badgeReservas={badgeReservas} />
      </div>
    </ToastProvider>
  );
}
