'use client';
import Link from 'next/link';
import { studio } from '@/config/studio';
import { iniciales } from '@/lib/theme';
export function StudioHeader({ noLeidas = 0, transparente = false }: { noLeidas?: number; transparente?: boolean }) {
  return (
    <header style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 46, paddingTop: 'var(--safe-top)', background: transparente ? 'transparent' : 'rgba(250,249,245,.88)', backdropFilter: transparente ? undefined : 'blur(16px)', borderBottom: transparente ? 'none' : '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1040, margin: '0 auto', height: 56, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 18px' }}>
        <Link href="/" aria-label={studio.nombre} style={{ display: 'flex', alignItems: 'center', gap: 9, color: transparente ? '#FAF9F5' : 'var(--foreground)' }}>
          {studio.logoUrl ? <img src={studio.logoUrl} alt="" style={{ height: 26 }} /> : <span style={{ width: 30, height: 30, borderRadius: 999, background: transparente ? 'rgba(250,249,245,.22)' : 'var(--accent)', color: transparente ? '#FAF9F5' : 'var(--accent-foreground)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11.5, fontWeight: 800 }}>{iniciales(studio.nombre)}</span>}
          <span style={{ fontSize: 14, fontWeight: 800, letterSpacing: '-.01em' }}>{studio.nombre}</span>
        </Link>
        <Link href="/notificaciones" aria-label={'Notificaciones' + (noLeidas ? ', ' + noLeidas + ' sin leer' : '')} style={{ position: 'relative', width: 40, height: 40, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid ' + (transparente ? 'rgba(255,255,255,.45)' : 'var(--border)'), background: transparente ? 'rgba(250,249,245,.22)' : 'var(--card)', color: transparente ? '#FAF9F5' : 'var(--foreground)' }}>
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" /><path d="M10 21a2 2 0 0 0 4 0" /></svg>
          {noLeidas > 0 && <span aria-hidden style={{ position: 'absolute', top: 8, right: 9, width: 8, height: 8, borderRadius: 99, background: 'var(--warning)', border: '1.5px solid #fff', animation: 'apDot .4s both' }} />}
        </Link>
      </div>
    </header>
  );
}
