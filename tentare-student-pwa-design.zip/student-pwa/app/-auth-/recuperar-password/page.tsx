'use client';
import { useState } from 'react';
import Link from 'next/link';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
export default function Recuperar() {
  const [email, setEmail] = useState(''); const [err, setErr] = useState(''); const [c, setC] = useState(false); const [ok, setOk] = useState(false);
  const enviar = async () => { if (!/.+@.+\..+/.test(email)) { setErr('Escribe un email válido'); return; } setErr(''); setC(true); await new Promise((x) => setTimeout(x, 900)); setC(false); setOk(true); };
  if (ok) return (
    <div className="a-pop" style={{ textAlign: 'center' }}>
      <span aria-hidden style={{ width: 64, height: 64, margin: '0 auto', borderRadius: 999, background: '#4F8A5B', color: '#fff', fontSize: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', animation: 'apCheck .55s var(--ease-spring) both' }}>✓</span>
      <h2 className="t-h1" style={{ fontSize: 22, marginTop: 16 }}>Revisa tu correo</h2>
      <p className="t-meta" style={{ marginTop: 6, fontSize: 13, lineHeight: 1.5 }}>Si <b>{email}</b> está registrado, te hemos enviado un enlace para crear una contraseña nueva. Caduca en 30 minutos.</p>
      <Link href="/login" className="btn btn--secondary" style={{ marginTop: 18 }}>Volver a entrar</Link>
      <p className="t-meta" style={{ marginTop: 14, fontSize: 12 }}>¿No llega? <button type="button" onClick={() => setOk(false)} style={{ border: 'none', background: 'none', fontWeight: 800, color: 'var(--accent)', padding: 0 }}>Reenviar</button></p>
    </div>
  );
  return (
    <form onSubmit={(e) => { e.preventDefault(); enviar(); }} style={{ display: 'flex', flexDirection: 'column', gap: 12 }} noValidate>
      <div><h2 className="t-h1" style={{ fontSize: 22 }}>Recuperar contraseña</h2><p className="t-meta" style={{ marginTop: 4, fontSize: 12.5 }}>Te enviamos un enlace para crear una nueva.</p></div>
      <Input label="Email" type="email" autoComplete="email" inputMode="email" value={email} onChange={(e) => setEmail(e.target.value)} error={err} />
      <Button type="submit" full loading={c}>Enviar enlace</Button>
      <Link href="/login" style={{ textAlign: 'center', fontSize: 12.5, fontWeight: 800 }}>Volver</Link>
    </form>
  );
}
