'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { useOnline } from '@/hooks/useOnline';
export default function Login() {
  const r = useRouter(); const { online } = useOnline();
  const [f, setF] = useState({ email: '', pass: '' }); const [err, setErr] = useState<Record<string, string>>({}); const [global, setGlobal] = useState(''); const [cargando, setC] = useState(false);
  const entrar = async () => {
    const e: Record<string, string> = {}; if (!/.+@.+\..+/.test(f.email)) e.email = 'Escribe un email válido'; if (!f.pass) e.pass = 'Escribe tu contraseña'; setErr(e); setGlobal(''); if (Object.keys(e).length) return;
    setC(true); await new Promise((x) => setTimeout(x, 900)); setC(false);
    if (f.pass === 'error') { setGlobal('Email o contraseña incorrectos. Prueba de nuevo o recupera tu contraseña.'); return; } // demo
    r.push('/');
  };
  return (
    <form onSubmit={(e) => { e.preventDefault(); entrar(); }} style={{ display: 'flex', flexDirection: 'column', gap: 12 }} noValidate>
      <div><h2 className="t-h1" style={{ fontSize: 22 }}>Hola de nuevo</h2><p className="t-meta" style={{ marginTop: 4, fontSize: 12.5 }}>Entra para reservar tu próxima clase.</p></div>
      {global && <p role="alert" style={{ margin: 0, background: 'var(--destructive-soft)', color: 'var(--destructive-foreground)', borderRadius: 12, padding: '10px 13px', fontSize: 12.5, fontWeight: 700 }}>{global}</p>}
      <Input label="Email" type="email" autoComplete="email" inputMode="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} error={err.email} />
      <Input label="Contraseña" type="password" autoComplete="current-password" value={f.pass} onChange={(e) => setF({ ...f, pass: e.target.value })} error={err.pass} />
      <Link href="/recuperar-password" style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)', alignSelf: 'flex-end', marginTop: -4 }}>¿Has olvidado la contraseña?</Link>
      <Button type="submit" full loading={cargando} disabled={!online} style={{ marginTop: 4 }}>{online ? 'Entrar' : 'Sin conexión'}</Button>
      <p className="t-meta" style={{ textAlign: 'center', fontSize: 12.5 }}>¿Primera vez? <Link href="/registro" style={{ fontWeight: 800, color: 'var(--foreground)' }}>Crear cuenta</Link></p>
    </form>
  );
}
