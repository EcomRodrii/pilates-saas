'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { studio } from '@/config/studio';
export default function Registro() {
  const r = useRouter();
  const [f, setF] = useState({ nombre: '', email: '', pass: '', acepto: false }); const [err, setErr] = useState<Record<string, string>>({}); const [c, setC] = useState(false);
  const crear = async () => {
    const e: Record<string, string> = {}; if (!f.nombre.trim()) e.nombre = 'Escribe tu nombre'; if (!/.+@.+\..+/.test(f.email)) e.email = 'Escribe un email válido'; if (f.pass.length < 8) e.pass = 'Mínimo 8 caracteres'; if (!f.acepto) e.acepto = 'Necesitamos tu consentimiento'; setErr(e); if (Object.keys(e).length) return;
    setC(true); await new Promise((x) => setTimeout(x, 900)); setC(false); r.push('/verificar-email?email=' + encodeURIComponent(f.email));
  };
  const fuerza = f.pass.length === 0 ? 0 : f.pass.length < 8 ? 1 : /[A-Z]/.test(f.pass) && /\d/.test(f.pass) ? 3 : 2;
  return (
    <form onSubmit={(e) => { e.preventDefault(); crear(); }} style={{ display: 'flex', flexDirection: 'column', gap: 12 }} noValidate>
      <div><h2 className="t-h1" style={{ fontSize: 22 }}>Crea tu cuenta</h2><p className="t-meta" style={{ marginTop: 4, fontSize: 12.5 }}>Para reservar en {studio.nombre}. Un minuto.</p></div>
      <Input label="Nombre" autoComplete="given-name" value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} error={err.nombre} />
      <Input label="Email" type="email" autoComplete="email" inputMode="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} error={err.email} />
      <div>
        <Input label="Contraseña" type="password" autoComplete="new-password" value={f.pass} onChange={(e) => setF({ ...f, pass: e.target.value })} error={err.pass} />
        <div aria-hidden style={{ display: 'flex', gap: 4, marginTop: 8 }}>{[1, 2, 3].map((n) => <span key={n} style={{ flex: 1, height: 4, borderRadius: 99, background: fuerza >= n ? (fuerza === 1 ? 'var(--warning)' : '#4F8A5B') : 'var(--muted)', transition: 'background .25s' }} />)}</div>
      </div>
      <label style={{ display: 'flex', gap: 10, alignItems: 'flex-start', cursor: 'pointer' }}>
        <button type="button" role="checkbox" aria-checked={f.acepto} aria-label="Acepto la política de privacidad" onClick={() => setF({ ...f, acepto: !f.acepto })} style={{ width: 20, height: 20, flexShrink: 0, marginTop: 1, borderRadius: 6, border: 'none', background: f.acepto ? 'var(--accent)' : 'var(--card)', boxShadow: f.acepto ? 'none' : 'inset 0 0 0 1.5px var(--border-strong)', color: '#fff', fontSize: 12, fontWeight: 800, transition: 'all .2s' }}>{f.acepto ? '✓' : ''}</button>
        <span style={{ fontSize: 12, color: 'var(--muted-foreground)', lineHeight: 1.5 }}>Al inscribirme, acepto la <u style={{ color: 'var(--foreground)', fontWeight: 700 }}>política de privacidad</u> de {studio.nombre}.</span>
      </label>
      {err.acepto && <p role="alert" className="field-error" style={{ marginTop: -6 }}>{err.acepto}</p>}
      <Button type="submit" full loading={c} style={{ marginTop: 4 }}>Crear cuenta</Button>
      <p className="t-meta" style={{ textAlign: 'center', fontSize: 12.5 }}>¿Ya tienes cuenta? <Link href="/login" style={{ fontWeight: 800, color: 'var(--foreground)' }}>Entrar</Link></p>
    </form>
  );
}
