'use client';
import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/Button';
function Verificar() {
  const sp = useSearchParams(); const r = useRouter(); const email = sp.get('email') ?? 'tu email';
  const [cod, setCod] = useState(['', '', '', '']); const [err, setErr] = useState(''); const [c, setC] = useState(false);
  const set = (i: number, v: string) => { const n = [...cod]; n[i] = v.replace(/\D/g, '').slice(-1); setCod(n); if (v && i < 3) (document.getElementById('cod-' + (i + 1)) as HTMLInputElement | null)?.focus(); };
  const confirmar = async () => { if (cod.join('').length < 4) { setErr('Introduce los 4 dígitos'); return; } setErr(''); setC(true); await new Promise((x) => setTimeout(x, 900)); setC(false); if (cod.join('') !== '4729') { setErr('Código incorrecto. En la demo es 4729.'); return; } r.push('/'); };
  return (
    <form onSubmit={(e) => { e.preventDefault(); confirmar(); }} style={{ display: 'flex', flexDirection: 'column', gap: 14 }} noValidate>
      <div><h2 className="t-h1" style={{ fontSize: 22 }}>Verifica tu email</h2><p className="t-meta" style={{ marginTop: 4, fontSize: 12.5, lineHeight: 1.5 }}>Hemos enviado un código de 4 dígitos a <b>{email}</b>.</p></div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }} role="group" aria-label="Código de verificación">
        {cod.map((v, i) => <input key={i} id={'cod-' + i} inputMode="numeric" autoComplete="one-time-code" aria-label={'Dígito ' + (i + 1)} aria-invalid={!!err || undefined} value={v} onChange={(e) => set(i, e.target.value)} className="input" style={{ width: 56, height: 62, textAlign: 'center', fontSize: 24, fontWeight: 800, padding: 0, fontFamily: 'var(--font-mono)' }} />)}
      </div>
      {err && <p role="alert" className="field-error" style={{ textAlign: 'center', margin: 0 }}>{err}</p>}
      <Button type="submit" full loading={c}>Confirmar</Button>
      <p className="t-meta" style={{ textAlign: 'center', fontSize: 12 }}>¿No lo recibes? <button type="button" style={{ border: 'none', background: 'none', fontWeight: 800, color: 'var(--accent)', padding: 0 }}>Reenviar código</button></p>
    </form>
  );
}
export default function Page() { return <Suspense fallback={null}><Verificar /></Suspense>; }
