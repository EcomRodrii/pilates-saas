'use client';
import { useEffect } from 'react';
import { studio } from '@/config/studio';
import { aplicarTema, iniciales } from '@/lib/theme';
import { ToastProvider } from '@/hooks/useToast';
/** Marco de auth: portada fotográfica oscura arriba, formulario sobre crema abajo. En ≥768px, dos columnas. */
export default function AuthLayout({ children }: { children: React.ReactNode }) {
  useEffect(() => { aplicarTema(studio.tema); }, []);
  return (
    <ToastProvider>
      <div className="auth">
        <style>{`
          .auth{min-height:100dvh;display:flex;flex-direction:column;background:var(--background)}
          .auth-hero{position:relative;height:38vh;min-height:250px;overflow:hidden;background:#0F0F0C;flex:none}
          .auth-body{flex:1;padding:22px 22px calc(24px + var(--safe-bottom));max-width:480px;width:100%;margin:0 auto}
          @media(min-width:768px){.auth{flex-direction:row}.auth-hero{height:auto;min-height:100dvh;flex:1 1 50%}.auth-body{flex:0 0 480px;display:flex;flex-direction:column;justify-content:center;padding:40px}}
        `}</style>
        <div className="auth-hero">
          <img src={studio.fotoPortada} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 40%', animation: 'apKen 22s ease-in-out infinite' }} />
          <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(8,8,8,.45), rgba(8,8,8,.05) 35%, rgba(8,8,8,.7))' }} />
          <div style={{ position: 'absolute', top: 'calc(18px + var(--safe-top))', left: 22, display: 'flex', alignItems: 'center', gap: 9, color: '#FAF9F5' }}>
            {studio.logoUrl ? <img src={studio.logoUrl} alt="" style={{ height: 26 }} /> : <span style={{ width: 30, height: 30, borderRadius: 999, background: 'rgba(250,249,245,.22)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11.5, fontWeight: 800 }}>{iniciales(studio.nombre)}</span>}
            <span style={{ fontSize: 15, fontWeight: 800, letterSpacing: '-.02em' }}>{studio.nombre}</span>
          </div>
          <div style={{ position: 'absolute', left: 22, right: 22, bottom: 22, color: '#FAF9F5' }}>
            <p className="t-label a-up" style={{ color: 'rgba(250,249,245,.75)' }}>{studio.disciplinas.join(' · ')} · {studio.ciudad}</p>
            <h1 className="a-up" style={{ margin: '10px 0 0', fontSize: 34, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1.06, animationDelay: '80ms' }}>Muévete.<br />Lo demás,<br />ya está.</h1>
          </div>
        </div>
        <div className="auth-body">{children}</div>
      </div>
    </ToastProvider>
  );
}
