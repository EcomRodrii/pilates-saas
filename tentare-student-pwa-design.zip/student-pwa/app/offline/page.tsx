import Link from 'next/link';
import { studio } from '@/config/studio';
/** Fallback del service worker cuando no hay red ni caché. */
export default function Offline() {
  return (
    <main style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: 28, background: 'var(--background)' }}>
      <span aria-hidden style={{ fontSize: 40 }}>📡</span>
      <h1 className="t-h1" style={{ marginTop: 14, fontSize: 24 }}>Sin conexión</h1>
      <p className="t-meta" style={{ marginTop: 8, fontSize: 13.5, lineHeight: 1.5, maxWidth: 320 }}>No podemos cargar {studio.nombre} ahora mismo. Tus reservas siguen igual — revísalas cuando vuelva la red.</p>
      <Link href="/" className="btn btn--primary" style={{ marginTop: 22 }}>Reintentar</Link>
    </main>
  );
}
