import type { Metadata, Viewport } from 'next';
import { Plus_Jakarta_Sans, IBM_Plex_Mono } from 'next/font/google';
import '@/styles/globals.css';
import { studio } from '@/config/studio';

const jakarta = Plus_Jakarta_Sans({ subsets: ['latin'], weight: ['400', '500', '600', '700', '800'], variable: '--font-jakarta', display: 'swap' });
const plex = IBM_Plex_Mono({ subsets: ['latin'], weight: ['400', '500'], variable: '--font-plex', display: 'swap' });

export const metadata: Metadata = { title: studio.nombre, description: 'La app de ' + studio.nombre, manifest: '/manifest.webmanifest', appleWebApp: { capable: true, statusBarStyle: 'black-translucent', title: studio.nombre }, icons: { icon: '/icons/icon-192.png', apple: '/icons/icon-192.png' } };
export const viewport: Viewport = { themeColor: '#FAF9F5', width: 'device-width', initialScale: 1, viewportFit: 'cover' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={jakarta.variable + ' ' + plex.variable} style={{ ['--font-sans' as string]: 'var(--font-jakarta), system-ui, sans-serif', ['--font-mono' as string]: 'var(--font-plex), ui-monospace, monospace' }}>
      <body>{children}</body>
    </html>
  );
}
