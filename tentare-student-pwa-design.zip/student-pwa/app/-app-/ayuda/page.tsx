'use client';
import { studio } from '@/config/studio';
import { PageHeader } from '@/components/shell/PageHeader';
import { ProfileSection } from '@/components/domain/ProfileSection';
const FAQ = [
  ['¿Cómo cancelo una clase?', 'Desde Mis clases → Cancelar. Si faltan más de ' + studio.politicaCancelacionHoras + ' h, recuperas la sesión de tu bono.'],
  ['¿Qué pasa si la clase está llena?', 'Puedes apuntarte a la lista de espera. Te avisamos al momento si se libera una plaza y decides si la quieres.'],
  ['¿Cómo funciona el pase de acceso?', 'Al entrar al estudio, abre tu reserva: el pase se valida solo. No necesitas imprimir nada.'],
  ['¿Caducan los bonos?', 'Depende del bono; lo ves en Bonos → detalle. Te avisamos antes de que caduque.'],
];
export default function Ayuda() {
  return (
    <>
      <PageHeader titulo="Ayuda" sub={studio.nombre} back />
      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 14 }}>
        <ProfileSection titulo="Contacto" items={[{ label: 'Llamar al estudio', href: 'tel:' + studio.telefono.replace(/\s/g, ''), valor: studio.telefono }, { label: 'Escribir un email', href: 'mailto:' + studio.email, valor: studio.email }, { label: 'Cómo llegar', href: 'https://maps.google.com/?q=' + encodeURIComponent(studio.direccion + ' ' + studio.ciudad), valor: studio.direccion }]} />
        <section>
          <p className="t-label" style={{ margin: '0 0 7px' }}>Preguntas frecuentes</p>
          <div className="card" style={{ overflow: 'hidden' }}>{FAQ.map(([q, a], i) => <details key={q} style={{ borderBottom: i < FAQ.length - 1 ? '1px solid var(--muted)' : 'none' }}><summary style={{ listStyle: 'none', cursor: 'pointer', padding: '13px 15px', fontSize: 13, fontWeight: 700, display: 'flex', justifyContent: 'space-between' }}>{q}<span aria-hidden style={{ color: 'var(--accent)' }}>+</span></summary><p style={{ margin: 0, padding: '0 15px 13px', fontSize: 12.5, lineHeight: 1.55, color: 'var(--muted-foreground)' }}>{a}</p></details>)}</div>
        </section>
        <p className="t-meta" style={{ fontSize: 10.5, color: 'var(--subtle-foreground)' }}>Aviso legal · Privacidad · Cookies</p>
      </div>
    </>
  );
}
