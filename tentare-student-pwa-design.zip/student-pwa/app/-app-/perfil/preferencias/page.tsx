'use client';
import { useState } from 'react';
import { PageHeader } from '@/components/shell/PageHeader';
function Toggle({ on, onChange, label, sub }: { on: boolean; onChange: (v: boolean) => void; label: string; sub?: string }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '13px 15px', minHeight: 56, borderBottom: '1px solid var(--muted)', cursor: 'pointer' }}>
      <span><span style={{ display: 'block', fontSize: 13, fontWeight: 700 }}>{label}</span>{sub && <span className="t-meta" style={{ display: 'block', marginTop: 1 }}>{sub}</span>}</span>
      <button type="button" role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} style={{ position: 'relative', width: 44, height: 26, borderRadius: 99, border: 'none', background: on ? '#4F8A5B' : 'var(--border-strong)', transition: 'background .25s', flexShrink: 0 }}><span aria-hidden style={{ position: 'absolute', top: 3, left: 3, width: 20, height: 20, borderRadius: 99, background: '#fff', boxShadow: '0 2px 6px rgba(26,26,26,.25)', transform: on ? 'translateX(18px)' : 'none', transition: 'transform .25s var(--ease-spring)' }} /></button>
    </label>
  );
}
export default function Preferencias() {
  const [p, setP] = useState({ recordatorio: true, plaza: true, novedades: false, email: true });
  return (
    <>
      <PageHeader titulo="Preferencias" back />
      <div className="px" style={{ marginTop: 14, maxWidth: 520 }}>
        <p className="t-label" style={{ margin: '0 0 7px' }}>Notificaciones push</p>
        <div className="card" style={{ overflow: 'hidden' }}>
          <Toggle on={p.recordatorio} onChange={(v) => setP({ ...p, recordatorio: v })} label="Recordatorio de clase" sub="El día antes y 2 h antes" />
          <Toggle on={p.plaza} onChange={(v) => setP({ ...p, plaza: v })} label="Plaza liberada" sub="Cuando estés en lista de espera" />
          <Toggle on={p.novedades} onChange={(v) => setP({ ...p, novedades: v })} label="Novedades del estudio" />
        </div>
        <p className="t-label" style={{ margin: '16px 0 7px' }}>Email</p>
        <div className="card" style={{ overflow: 'hidden' }}><Toggle on={p.email} onChange={(v) => setP({ ...p, email: v })} label="Recibos y confirmaciones por email" /></div>
      </div>
    </>
  );
}
