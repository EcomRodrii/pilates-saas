'use client';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { alumna } from '@/mocks/data';
import { studio } from '@/config/studio';
import { iniciales } from '@/lib/theme';
import { PageHeader } from '@/components/shell/PageHeader';
import { ProfileSection } from '@/components/domain/ProfileSection';
import { ConfirmationDialog } from '@/components/ui/ConfirmationDialog';

export default function Perfil() {
  const r = useRouter(); const [salir, setSalir] = useState(false);
  return (
    <>
      <PageHeader titulo="Perfil" />
      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
          <span aria-hidden style={{ width: 56, height: 56, borderRadius: 999, background: alumna.fotoUrl ? 'url(' + alumna.fotoUrl + ') center/cover' : 'var(--accent-soft)', color: 'var(--accent-soft-foreground)', fontSize: 19, fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{!alumna.fotoUrl && iniciales(alumna.nombre + ' ' + alumna.apellidos)}</span>
          <div><p style={{ margin: 0, fontSize: 17, fontWeight: 800 }}>{alumna.nombre} {alumna.apellidos}</p><p className="t-meta" style={{ marginTop: 1, fontSize: 12 }}>Alumna de {studio.nombre}</p></div>
        </div>
        <ProfileSection titulo="Cuenta" items={[{ label: 'Datos personales', href: '/perfil/datos', valor: alumna.email }, { label: 'Preferencias', href: '/perfil/preferencias' }, { label: 'Bonos', href: '/bonos' }, { label: 'Pagos y recibos', href: '/pagos' }]} />
        <ProfileSection titulo="Estudio" items={[{ label: 'Ayuda y contacto', href: '/ayuda' }, { label: 'Notificaciones', href: '/notificaciones' }]} />
        <ProfileSection titulo="Sesión" items={[{ label: 'Cerrar sesión', onClick: () => setSalir(true), destructivo: true }]} />
        <p className="t-meta" style={{ textAlign: 'center', fontSize: 10.5, color: 'var(--subtle-foreground)' }}>App de {studio.nombre} · con Tentare</p>
      </div>
      <ConfirmationDialog open={salir} onClose={() => setSalir(false)} titulo="¿Cerrar sesión?" cuerpo="Tendrás que volver a identificarte para reservar." confirmar="Cerrar sesión" tono="danger" onConfirm={() => r.push('/login')} />
    </>
  );
}
