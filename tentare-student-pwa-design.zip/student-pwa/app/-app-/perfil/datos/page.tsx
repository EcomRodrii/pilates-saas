'use client';
import { useState } from 'react';
import { alumna } from '@/mocks/data';
import { PageHeader } from '@/components/shell/PageHeader';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { useToast } from '@/hooks/useToast';
import { useOnline } from '@/hooks/useOnline';
export default function Datos() {
  const { toast } = useToast(); const { online } = useOnline();
  const [f, setF] = useState({ nombre: alumna.nombre, apellidos: alumna.apellidos, email: alumna.email, telefono: alumna.telefono ?? '' });
  const [err, setErr] = useState<Record<string, string>>({}); const [guardando, setG] = useState(false);
  const guardar = async () => { const e: Record<string, string> = {}; if (!f.nombre.trim()) e.nombre = 'Escribe tu nombre'; if (!/.+@.+\..+/.test(f.email)) e.email = 'Revisa el email'; setErr(e); if (Object.keys(e).length) return; setG(true); await new Promise((r) => setTimeout(r, 800)); setG(false); toast('Datos guardados ✓'); };
  return (
    <>
      <PageHeader titulo="Datos personales" back />
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14, maxWidth: 520 }}>
        <Input label="Nombre" value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} error={err.nombre} autoComplete="given-name" />
        <Input label="Apellidos" value={f.apellidos} onChange={(e) => setF({ ...f, apellidos: e.target.value })} autoComplete="family-name" />
        <Input label="Email" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} error={err.email} hint="Si lo cambias te enviaremos un código de verificación." autoComplete="email" />
        <Input label="Teléfono" type="tel" value={f.telefono} onChange={(e) => setF({ ...f, telefono: e.target.value })} autoComplete="tel" />
        <Button full loading={guardando} disabled={!online} onClick={guardar} style={{ marginTop: 6 }}>{online ? 'Guardar cambios' : 'Sin conexión'}</Button>
        <Button variant="ghost" full onClick={() => toast('Cambio de contraseña: pendiente de backend')}>Cambiar contraseña</Button>
      </div>
    </>
  );
}
