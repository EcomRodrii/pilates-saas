'use client';
import { useState } from 'react';
import { useAsync } from '@/hooks/useAsync';
import { getBonos, getClases, getInstructoras, getReservas } from '@/lib/data';
import { studio } from '@/config/studio';
import { etiquetaDia, hoyISO } from '@/lib/format';
import { disponibilidad } from '@/lib/booking-machine';
import { PageHeader } from '@/components/shell/PageHeader';
import { Calendar } from '@/components/domain/Calendar';
import { ClassCard } from '@/components/domain/ClassCard';
import { EmptyState, ErrorState, ListSkeleton, OfflineState, Skeleton } from '@/components/ui/States';

export default function Calendario() {
  const [dia, setDia] = useState(hoyISO());
  const { data, estado, reintentar } = useAsync(async () => { const [clases, reservas, bonos, inst] = await Promise.all([getClases(), getReservas(), getBonos(), getInstructoras()]); return { clases, reservas, bonos, inst }; }, () => false);
  const reservadas = (data?.reservas ?? []).filter((r) => r.estado === 'confirmada').map((r) => data!.clases.find((c) => c.id === r.claseId)?.fecha).filter(Boolean) as string[];
  const lista = (data?.clases ?? []).filter((c) => c.fecha === dia).sort((a, b) => a.hora.localeCompare(b.hora));
  const bono = data?.bonos.find((b) => b.estado === 'activo');
  return (
    <>
      <PageHeader titulo="Calendario" back />
      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 14, marginTop: 14 }}>
        {estado === 'loading' ? <Skeleton h={330} r={16} /> : <Calendar value={dia} onChange={setDia} marcados={reservadas} />}
        <section>
          <p className="t-label" style={{ margin: '0 0 9px' }}>{etiquetaDia(dia)} · {lista.length} clases</p>
          {estado === 'loading' && <ListSkeleton n={3} />}
          {estado === 'error' && <ErrorState onRetry={reintentar} />}
          {estado === 'offline' && !data && <OfflineState />}
          {data && estado !== 'loading' && estado !== 'error' && (lista.length === 0 ? <EmptyState icono="🌿" titulo="Día sin clases" cuerpo="El estudio no programa clases este día." /> : <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>{lista.map((c, i) => <ClassCard key={c.id} clase={c} instructora={data.inst.find((x) => x.id === c.instructoraId)} estado={disponibilidad(c, data.reservas, studio.soportaListaEspera)} conBono={!!bono} delay={i * 55} />)}</div>)}
        </section>
      </div>
    </>
  );
}
