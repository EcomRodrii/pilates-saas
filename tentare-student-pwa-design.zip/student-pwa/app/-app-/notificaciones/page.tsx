'use client';
import { useAsync } from '@/hooks/useAsync';
import { getNotificaciones } from '@/lib/data';
import { PageHeader } from '@/components/shell/PageHeader';
import { NotificationItem } from '@/components/domain/NotificationItem';
import { EmptyState, ErrorState, ListSkeleton, OfflineState } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';
export default function Notificaciones() {
  const { data, estado, reintentar } = useAsync(getNotificaciones); const { toast } = useToast();
  const noLeidas = data?.filter((n) => !n.leida).length ?? 0;
  return (
    <>
      <PageHeader titulo="Notificaciones" sub={noLeidas ? noLeidas + ' sin leer' : undefined} back accion={noLeidas > 0 ? <button type="button" className="btn btn--secondary btn--sm" onClick={() => toast('Marcadas como leídas ✓')}>Marcar leídas</button> : undefined} />
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 14 }}>
        {estado === 'loading' && <ListSkeleton n={4} h={78} />}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState />}
        {estado === 'empty' && <EmptyState icono="🔔" titulo="Todo al día" cuerpo="Te avisaremos de plazas liberadas, recordatorios y novedades del estudio." />}
        {estado === 'ready' && data?.map((n, i) => <NotificationItem key={n.id} n={n} delay={i * 50} />)}
      </div>
    </>
  );
}
