'use client';
import { useParams, useRouter } from 'next/navigation';
import { useAsync } from '@/hooks/useAsync';
import { getClases, getInstructoras, getReservas } from '@/lib/data';
import { clasesPasadas } from '@/mocks/data';
import { studio } from '@/config/studio';
import { etiquetaDia, fechaLarga } from '@/lib/format';
import { PageHeader } from '@/components/shell/PageHeader';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ErrorState, Skeleton } from '@/components/ui/States';
import { useToast } from '@/hooks/useToast';

export default function DetalleReserva() {
  const { bookingId } = useParams<{ bookingId: string }>(); const r = useRouter(); const { toast } = useToast();
  const { data, estado, reintentar } = useAsync(async () => { const [reservas, clases, inst] = await Promise.all([getReservas(), getClases(), getInstructoras()]); const res = reservas.find((x) => x.id === bookingId); const c = [...clases, ...clasesPasadas].find((x) => x.id === res?.claseId); return res && c ? { res, c, i: inst.find((x) => x.id === c.instructoraId) } : null; }, (d) => !d);
  if (estado === 'loading') return <div className="px" style={{ paddingTop: 12, display: 'flex', flexDirection: 'column', gap: 12 }}><Skeleton h={30} w="50%" /><Skeleton h={260} r={20} /><Skeleton h={120} r={16} /></div>;
  if (!data) return <div className="px" style={{ paddingTop: 12 }}><ErrorState titulo="No encontramos esta reserva" onRetry={reintentar} /></div>;
  const { res, c, i } = data; const activa = res.estado === 'confirmada';
  return (
    <>
      <PageHeader titulo="Tu reserva" back />
      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 13, marginTop: 14 }}>
        {/* Pase de acceso (kit: verde noche + QR) — solo si activa */}
        {activa ? (
          <section aria-label="Pase de acceso" className="a-pop" style={{ background: 'var(--accent-deep)', color: 'var(--accent-deep-foreground)', borderRadius: 22, padding: '20px 18px', textAlign: 'center', boxShadow: 'var(--shadow-hero)' }}>
            <p className="t-label" style={{ color: 'var(--accent-deep-muted)' }}>Pase de acceso · {studio.nombre}</p>
            <div style={{ width: 168, height: 168, margin: '14px auto 0', background: '#FAF9F5', borderRadius: 18, padding: 14, display: 'grid', gridTemplateColumns: 'repeat(9,1fr)', gap: 3 }} aria-label="Código QR de acceso" role="img">
              {Array.from({ length: 81 }).map((_, k) => <span key={k} style={{ background: ((k * 7 + 3) % 5 < 2 || k % 9 === 0 || k < 9) ? '#12291A' : 'transparent', borderRadius: 1 }} />)}
            </div>
            <p style={{ margin: '14px 0 0', fontSize: 16, fontWeight: 800, color: '#FAF9F5' }}>{c.nombre}</p>
            <p style={{ margin: '3px 0 0', fontSize: 12, color: 'rgba(234,240,231,.75)' }}>{fechaLarga(c.fecha)} · {c.hora} · con {i?.nombre}</p>
            <p className="t-mono" style={{ margin: '10px 0 0', fontSize: 10, color: 'var(--accent-deep-muted)' }}>Se valida solo al llegar · ref {res.id.toUpperCase()}</p>
          </section>
        ) : (
          <div className="card" style={{ padding: '14px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div><p style={{ margin: 0, fontSize: 14, fontWeight: 800 }}>{c.nombre}</p><p className="t-meta" style={{ marginTop: 2 }}>{fechaLarga(c.fecha)} · {c.hora}</p></div><Badge tone={res.estado === 'asistida' ? 'ok' : 'neutral'}>{res.estado === 'asistida' ? 'Asistida' : res.estado === 'cancelada' ? 'Cancelada' : res.estado === 'en-espera' ? 'En espera' : 'No asistió'}</Badge></div>
        )}
        <div className="card" style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12.5 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Instructora</span><b>{i?.nombre}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Sala</span><b>{c.sala}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Dirección</span><b style={{ textAlign: 'right' }}>{studio.direccion}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Pagada con</span><b>{res.pagadaCon === 'bono' ? 'Bono · 1 sesión' : res.pagadaCon}</b></div>
        </div>
        {activa && (
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="secondary" full onClick={() => toast('Abriendo cómo llegar… 📍')}>Cómo llegar</Button>
            <Button variant="secondary" full onClick={() => toast('Añadida a tu calendario ✓')}>+ Calendario</Button>
          </div>
        )}
        {activa && <Button variant="ghost" full onClick={() => r.push('/mis-reservas')}>Gestionar o cancelar</Button>}
        {res.estado === 'asistida' && <Button variant="secondary" full onClick={() => toast('Valoración: pendiente de backend')}>Valorar la clase ★</Button>}
      </div>
    </>
  );
}
