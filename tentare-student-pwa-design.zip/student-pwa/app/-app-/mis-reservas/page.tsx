'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useAsync } from '@/hooks/useAsync';
import { useOnline } from '@/hooks/useOnline';
import { useToast } from '@/hooks/useToast';
import { cancelarReserva, getClases, getInstructoras, getReservas } from '@/lib/data';
import { clasesPasadas } from '@/mocks/data';
import { studio } from '@/config/studio';
import { etiquetaDia, fechaCorta } from '@/lib/format';
import { cancelable } from '@/lib/booking-machine';
import { PageHeader } from '@/components/shell/PageHeader';
import { Badge } from '@/components/ui/Badge';
import { ConfirmationDialog } from '@/components/ui/ConfirmationDialog';
import { EmptyState, ErrorState, ListSkeleton, OfflineState } from '@/components/ui/States';

export default function MisReservas() {
  const [tab, setTab] = useState<'prox' | 'hist'>('prox');
  const [cancelId, setCancelId] = useState<string | null>(null);
  const [cancelando, setCancelando] = useState(false);
  const [canceladas, setCanceladas] = useState<string[]>([]);
  const { online } = useOnline(); const { toast } = useToast();
  const { data, estado, reintentar } = useAsync(async () => { const [reservas, clases, inst] = await Promise.all([getReservas(), getClases(), getInstructoras()]); return { reservas, clases: [...clases, ...clasesPasadas], inst }; }, () => false);
  const items = (data?.reservas ?? []).map((r) => ({ r, c: data!.clases.find((c) => c.id === r.claseId)! })).filter((x) => x.c);
  const prox = items.filter((x) => x.r.estado === 'confirmada' || x.r.estado === 'en-espera').filter((x) => !canceladas.includes(x.r.id));
  const hist = items.filter((x) => x.r.estado === 'asistida' || x.r.estado === 'no-asistida' || x.r.estado === 'cancelada' || canceladas.includes(x.r.id));
  const sel = items.find((x) => x.r.id === cancelId);
  const pol = sel ? cancelable(sel.c, studio.politicaCancelacionHoras) : null;

  const confirmarCancel = async () => {
    if (!sel) return; setCancelando(true);
    const res = await cancelarReserva(sel.r.id, sel.r.id === 'r-fail'); // 'r-fail' simula fallo (demo)
    setCancelando(false);
    if (!res.ok) { toast('No hemos podido cancelar. Tu reserva sigue activa.'); return; }
    setCanceladas((c) => [...c, sel.r.id]); setCancelId(null);
    toast(res.devuelveCredito ? 'Cancelada · sesión devuelta a tu bono ✓' : 'Cancelada — la sesión no se devuelve');
  };

  return (
    <>
      <PageHeader titulo="Mis clases" />
      <div className="px" style={{ position: 'relative', display: 'flex', background: 'var(--muted)', borderRadius: 999, padding: 4, margin: '14px 18px 0' }}>
        <span aria-hidden style={{ position: 'absolute', top: 4, bottom: 4, left: 4, width: 'calc(50% - 4px)', background: 'var(--card)', borderRadius: 999, boxShadow: '0 3px 10px rgba(26,26,26,.1)', transform: tab === 'hist' ? 'translateX(100%)' : 'none', transition: 'transform .32s var(--ease-spring)' }} />
        {(['prox', 'hist'] as const).map((t) => <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} style={{ flex: 1, position: 'relative', border: 'none', background: 'none', padding: '9px 0', fontSize: 12.5, fontWeight: 800, color: tab === t ? 'var(--foreground)' : 'var(--subtle-foreground)', transition: 'color .25s' }}>{t === 'prox' ? 'Próximas' : 'Historial'}</button>)}
      </div>
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 9, marginTop: 14 }}>
        {estado === 'loading' && <ListSkeleton n={2} h={110} />}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState />}
        {data && estado !== 'loading' && estado !== 'error' && (tab === 'prox' ? (
          prox.length === 0 ? <EmptyState icono="🗓" titulo="No tienes clases próximas" cuerpo="Reserva tu siguiente sesión — hay plazas hoy." accion="Ver horario" href="/reservar" /> :
          prox.map(({ r, c }) => {
            const i = data.inst.find((x) => x.id === c.instructoraId); const p = cancelable(c, studio.politicaCancelacionHoras); const espera = r.estado === 'en-espera';
            return (
              <div key={r.id} className="a-pop" style={{ background: espera ? 'var(--card)' : 'var(--accent-soft)', border: '1px solid ' + (espera ? 'var(--border)' : 'transparent'), borderRadius: 17, padding: '13px 15px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <p style={{ margin: 0, fontSize: 13, fontWeight: 800, color: espera ? 'var(--foreground)' : 'var(--accent-soft-foreground)' }}>{etiquetaDia(c.fecha)} · {c.hora}</p>
                  <Badge tone={espera ? 'wait' : 'ok'}>{espera ? 'Lista de espera · ' + (r.posicionEspera ?? 2) + 'ª' : 'Confirmada ✓'}</Badge>
                </div>
                <p style={{ margin: '3px 0 0', fontSize: 13.5, fontWeight: 700 }}>{c.nombre}</p>
                <p className="t-meta" style={{ marginTop: 2 }}>con {i?.nombre} · {c.sala} · pagada con {r.pagadaCon}</p>
                <div style={{ display: 'flex', gap: 7, marginTop: 10, flexWrap: 'wrap' }}>
                  <Link href={'/mis-reservas/' + r.id} className="btn btn--light btn--sm" style={{ height: 34 }}>Detalle</Link>
                  <button type="button" className="btn btn--light btn--sm" style={{ height: 34 }} onClick={() => toast('Añadida a tu calendario ✓')}>+ Calendario</button>
                  <button type="button" className="btn btn--danger btn--sm" style={{ height: 34 }} disabled={!online || !p.puede} title={!online ? 'Necesitas conexión' : undefined} onClick={() => setCancelId(r.id)}>{espera ? 'Salir de la lista' : 'Cancelar'}</button>
                </div>
              </div>
            );
          })
        ) : (
          hist.length === 0 ? <EmptyState icono="📖" titulo="Aún no hay historial" cuerpo="Aquí verás las clases a las que has ido." /> :
          hist.map(({ r, c }) => <Link key={r.id} href={'/mis-reservas/' + r.id} className="card card--tap" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '11px 14px' }}><div><p style={{ margin: 0, fontSize: 12.5, fontWeight: 700 }}>{c.nombre}</p><p className="t-meta" style={{ marginTop: 1 }}>{fechaCorta(c.fecha)} · {c.hora}</p></div><Badge tone={r.estado === 'asistida' ? 'ok' : canceladas.includes(r.id) || r.estado === 'cancelada' ? 'neutral' : 'few'}>{canceladas.includes(r.id) ? 'Cancelada' : r.estado === 'asistida' ? 'Asistida' : r.estado === 'no-asistida' ? 'No asistió' : 'Cancelada'}</Badge></Link>)
        ))}
      </div>
      <ConfirmationDialog open={!!cancelId} onClose={() => !cancelando && setCancelId(null)} titulo={sel?.r.estado === 'en-espera' ? '¿Salir de la lista de espera?' : '¿Cancelar esta clase?'} cuerpo={sel ? sel.c.nombre + ' · ' + etiquetaDia(sel.c.fecha) + ' ' + sel.c.hora : ''} confirmar={sel?.r.estado === 'en-espera' ? 'Sí, salir' : pol?.devuelveCredito ? 'Sí, cancelar y recuperar sesión' : 'Sí, cancelar igualmente'} cancelar="Mantener mi reserva" tono="danger" loading={cancelando} onConfirm={confirmarCancel}>
        {sel && sel.r.estado !== 'en-espera' && <div style={{ background: pol?.devuelveCredito ? 'var(--accent-soft)' : 'var(--warning-soft)', borderRadius: 14, padding: '11px 14px', marginTop: 13 }}><p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: pol?.devuelveCredito ? 'var(--accent-soft-foreground)' : 'var(--warning-foreground)' }}>{pol?.devuelveCredito ? 'Estás dentro del plazo: recuperas la sesión de tu bono al instante.' : 'Quedan menos de ' + studio.politicaCancelacionHoras + ' h: la sesión no se devuelve.'}</p></div>}
      </ConfirmationDialog>
    </>
  );
}
