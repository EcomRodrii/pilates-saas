'use client';
import { useCallback, useState } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { useAsync } from '@/hooks/useAsync';
import { useOnline } from '@/hooks/useOnline';
import { useToast } from '@/hooks/useToast';
import { confirmarReserva, getBonos, getClase, getInstructoras, getReservas, type BookingOutcome } from '@/lib/data';
import { studio } from '@/config/studio';
import { etiquetaDia, euros } from '@/lib/format';
import { cancelable, disponibilidad } from '@/lib/booking-machine';
import type { BookingState } from '@/types';
import { AvailabilityBadge } from '@/components/ui/Badge';
import { Sheet } from '@/components/ui/Sheet';
import { Button } from '@/components/ui/Button';
import { ErrorState, OfflineState, Skeleton } from '@/components/ui/States';
import { BookingButton } from '@/components/domain/BookingButton';
import { BookingSummary } from '@/components/domain/BookingSummary';
import { BookingStatus } from '@/components/domain/BookingStatus';
import { InstructorCard } from '@/components/domain/InstructorCard';

export default function DetalleClase() {
  const { classId } = useParams<{ classId: string }>();
  const sp = useSearchParams(); const router = useRouter(); const { toast } = useToast(); const { online } = useOnline();
  // ?outcome=full|conflict|duplicate|session-expired|error|waitlisted fuerza el resultado del servidor (solo demo)
  const outcome = (sp.get('outcome') as BookingOutcome | null) ?? undefined;
  const { data, estado, reintentar } = useAsync(async () => { const [clase, reservas, bonos, inst] = await Promise.all([getClase(classId), getReservas(), getBonos(), getInstructoras()]); return { clase, reservas, bonos, inst }; }, (d) => !d.clase);
  const [bk, setBk] = useState<BookingState>('idle');

  const clase = data?.clase; const inst = data?.inst.find((i) => i.id === clase?.instructoraId);
  const disp = clase ? disponibilidad(clase, data!.reservas, studio.soportaListaEspera) : 'disponible';
  const bono = data?.bonos.find((b) => b.estado === 'activo' && b.creditosUsados < b.creditosTotales) ?? null;
  const pol = clase ? cancelable(clase, studio.politicaCancelacionHoras) : null;

  const confirmar = useCallback(async () => {
    if (!online) { setBk('offline'); return; }
    setBk('submitting');
    try { const r = await confirmarReserva(classId, outcome); setBk(r.state); }
    catch { setBk('error'); }
  }, [classId, online, outcome]);

  const cerrar = () => { if (bk === 'submitting') return; setBk('idle'); };
  const finalizar = () => { if (bk === 'confirmed' || bk === 'waitlisted') router.push('/mis-reservas'); else if (bk === 'session-expired') router.push('/login'); else setBk('idle'); };

  if (estado === 'loading') return <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}><Skeleton h={280} r={20} style={{ marginTop: -56 }} /><Skeleton h={22} w="60%" /><Skeleton h={12} w="80%" /><Skeleton h={74} r={14} /><Skeleton h={74} r={14} /></div>;
  if (estado === 'error' || !clase) return <div className="px" style={{ paddingTop: 12 }}><ErrorState titulo="No encontramos esta clase" cuerpo="Puede que se haya cancelado o movido de hora." onRetry={reintentar} /></div>;

  return (
    <>
      {/* Hero foto + título superpuesto */}
      <section style={{ position: 'relative', height: 290, marginTop: -56, overflow: 'hidden' }}>
        <img src={clase.fotoUrl} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', animation: 'apKen 18s ease-in-out infinite' }} />
        <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(15,15,15,.36), rgba(15,15,15,0) 36%, rgba(15,15,15,0) 55%, rgba(15,15,15,.64))' }} />
        <button type="button" onClick={() => router.back()} aria-label="Volver" style={{ position: 'absolute', top: 'calc(56px + var(--safe-top))', left: 14, width: 34, height: 34, border: 'none', borderRadius: 999, background: 'rgba(250,249,245,.92)', fontSize: 15 }}>←</button>
        <div style={{ position: 'absolute', left: 16, right: 16, bottom: 13, color: '#fff' }}>
          <p className="t-label" style={{ color: 'rgba(255,255,255,.82)' }}>{clase.tipo} · nivel {clase.nivel.toLowerCase()}</p>
          <h1 style={{ margin: '3px 0 0', fontSize: 26, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1.05 }}>{clase.nombre}</h1>
          <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <span className="badge" style={{ background: 'rgba(250,249,245,.2)', border: '1px solid rgba(255,255,255,.45)', color: '#fff' }}>{etiquetaDia(clase.fecha)} · {clase.hora}</span>
            <span className="badge" style={{ background: 'rgba(250,249,245,.2)', border: '1px solid rgba(255,255,255,.45)', color: '#fff' }}>{clase.duracionMin} min</span>
            <span className="badge" style={{ background: 'rgba(250,249,245,.2)', border: '1px solid rgba(255,255,255,.45)', color: '#fff' }}>{clase.sala}</span>
          </div>
        </div>
      </section>

      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 14, paddingTop: 14, paddingBottom: 90 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <AvailabilityBadge estado={disp} plazas={clase.plazasLibres} />
          <span style={{ fontSize: 12.5, fontWeight: 800, color: 'var(--muted-foreground)' }}>{bono ? 'Con tu bono · 1 sesión' : euros(clase.precioSuelto) + ' clase suelta'}</span>
        </div>
        {inst && <InstructorCard i={inst} onClick={() => toast('Perfil de instructora: pendiente de backend')} />}
        <p style={{ margin: 0, fontSize: 13, lineHeight: 1.6, color: 'var(--muted-foreground)' }}>{clase.descripcion ?? 'Grupo reducido de ' + clase.capacidad + ' personas. Ven con calcetines antideslizantes; si es tu primera vez, llega 10 minutos antes.'}</p>
        <div className="card" style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8 }}>
          <Row k="Cuándo" v={etiquetaDia(clase.fecha) + ' · ' + clase.hora + ' – ' + fin(clase.hora, clase.duracionMin)} />
          <Row k="Dónde" v={studio.direccion + ' · ' + clase.sala} />
          <Row k="Capacidad" v={clase.capacidad + ' personas · ' + clase.plazasLibres + ' libres'} />
          <Row k="Cancelación" v={pol?.devuelveCredito ? 'Gratis hasta ' + studio.politicaCancelacionHoras + ' h antes' : 'Ya no devuelve la sesión'} />
        </div>
        {!online && <OfflineState cuerpo="Puedes ver la clase, pero reservar necesita conexión." />}
      </div>

      {/* CTA persistente sobre la nav */}
      <div style={{ position: 'fixed', left: 0, right: 0, bottom: 'calc(var(--nav-height) + var(--safe-bottom))', zIndex: 39, padding: '10px 16px 12px', background: 'linear-gradient(180deg, rgba(250,249,245,0), var(--background) 40%)', maxWidth: 640, margin: '0 auto' }}>
        <BookingButton estado={disp} online={online} onReservar={() => setBk('reviewing')} onEspera={() => setBk('reviewing')} onCancelar={() => router.push('/mis-reservas')} />
      </div>

      {/* SHEET: revisar → confirmar → resultado del servidor */}
      <Sheet open={bk !== 'idle'} onClose={cerrar} label="Reservar clase">
        {(bk === 'reviewing' || bk === 'submitting') && (
          <>
            <h3 className="t-h2" style={{ fontSize: 18 }}>{disp === 'completa' ? 'Clase llena — lista de espera' : 'Confirma tu plaza'}</h3>
            <div style={{ marginTop: 12 }}><BookingSummary clase={clase} instructora={inst} bono={disp === 'completa' ? null : bono} politicaHoras={studio.politicaCancelacionHoras} /></div>
            {disp === 'completa' && <p className="t-meta" style={{ marginTop: 8, textAlign: 'center' }}>Sin coste — solo reservas si se libera y tú confirmas.</p>}
            <Button full loading={bk === 'submitting'} onClick={confirmar} style={{ marginTop: 14, height: 50, fontSize: 14 }}>{disp === 'completa' ? 'Unirme a la lista de espera' : 'Confirmar ' + clase.hora + (bono ? ' con bono' : ' · ' + euros(clase.precioSuelto))}</Button>
            {bk === 'submitting' && <p className="t-meta" style={{ marginTop: 8, textAlign: 'center' }}>Confirmando con el estudio… no cierres la app.</p>}
          </>
        )}
        {bk !== 'idle' && bk !== 'reviewing' && bk !== 'submitting' && (
          <BookingStatus state={bk} onRetry={() => setBk('reviewing')} onWaitlist={() => { setBk('reviewing'); }} onClose={finalizar} />
        )}
      </Sheet>
    </>
  );
}
function Row({ k, v }: { k: string; v: string }) { return <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, fontSize: 12.5 }}><span style={{ color: 'var(--muted-foreground)' }}>{k}</span><span style={{ fontWeight: 700, textAlign: 'right' }}>{v}</span></div>; }
function fin(h: string, min: number) { const [hh, mm] = h.split(':').map(Number); const t = hh * 60 + mm + min; return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
