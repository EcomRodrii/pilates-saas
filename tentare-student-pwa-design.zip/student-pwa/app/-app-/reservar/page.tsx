'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useAsync } from '@/hooks/useAsync';
import { getBonos, getClases, getInstructoras, getReservas } from '@/lib/data';
import { studio } from '@/config/studio';
import { etiquetaDia, hoyISO } from '@/lib/format';
import { disponibilidad } from '@/lib/booking-machine';
import { PageHeader } from '@/components/shell/PageHeader';
import { DateSelector } from '@/components/domain/DateSelector';
import { ClassCard } from '@/components/domain/ClassCard';
import { EmptyState, ErrorState, ListSkeleton, OfflineState } from '@/components/ui/States';

export default function Reservar() {
  const [dia, setDia] = useState(hoyISO());
  const [filtro, setFiltro] = useState('Todo');
  const { data, estado, reintentar } = useAsync(async () => { const [clases, reservas, bonos, inst] = await Promise.all([getClases(), getReservas(), getBonos(), getInstructoras()]); return { clases, reservas, bonos, inst }; }, () => false);
  const tipos = useMemo(() => ['Todo', ...Array.from(new Set(data?.clases.map((c) => c.tipo) ?? [])), 'Con hueco'], [data]);
  const lista = (data?.clases ?? []).filter((c) => c.fecha === dia).filter((c) => filtro === 'Todo' || (filtro === 'Con hueco' ? c.plazasLibres > 0 : c.tipo === filtro)).sort((a, b) => a.hora.localeCompare(b.hora));
  const bono = data?.bonos.find((b) => b.estado === 'activo');
  return (
    <>
      <PageHeader titulo="Horario" sub={studio.nombre} accion={<Link href="/calendario" className="btn btn--secondary btn--sm">Calendario</Link>} />
      <div style={{ marginTop: 14 }}><DateSelector value={dia} onChange={setDia} /></div>
      <div className="px no-scrollbar" style={{ display: 'flex', gap: 7, overflowX: 'auto', marginTop: 10 }}>
        {tipos.map((t) => <button key={t} type="button" className="pill" aria-pressed={filtro === t} onClick={() => setFiltro(t)} style={{ flexShrink: 0 }}>{t}</button>)}
      </div>
      <p className="t-label px" style={{ margin: '12px 0 9px' }}>{estado === 'loading' ? 'Cargando…' : lista.length + ' clases · ' + etiquetaDia(dia)}</p>
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
        {estado === 'loading' && <ListSkeleton n={4} />}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState />}
        {data && estado !== 'loading' && estado !== 'error' && (lista.length === 0
          ? <EmptyState icono="🔍" titulo={filtro === 'Todo' ? 'No hay clases este día' : 'No hay ' + filtro.toLowerCase() + ' este día'} cuerpo="Prueba otro día o quita el filtro." accion={filtro !== 'Todo' ? 'Quitar filtro' : undefined} onAccion={() => setFiltro('Todo')} />
          : lista.map((c, i) => <ClassCard key={c.id} clase={c} instructora={data.inst.find((x) => x.id === c.instructoraId)} estado={disponibilidad(c, data.reservas, studio.soportaListaEspera)} conBono={!!bono} delay={i * 55} />))}
      </div>
    </>
  );
}
