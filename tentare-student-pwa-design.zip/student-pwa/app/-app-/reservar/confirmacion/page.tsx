'use client';
import { useSearchParams, useRouter } from 'next/navigation';
import { BookingStatus } from '@/components/domain/BookingStatus';
import type { BookingState } from '@/types';
/** Pantalla de resultado accesible por URL: /reservar/confirmacion?state=confirmed. El estado SIEMPRE lo fija el servidor. */
export default function Confirmacion() {
  const sp = useSearchParams(); const r = useRouter();
  const st = (sp.get('state') ?? 'confirmed') as Exclude<BookingState, 'idle' | 'reviewing' | 'submitting'>;
  return (
    <div className="px" style={{ maxWidth: 420, margin: '40px auto 0' }}>
      <BookingStatus state={st} onRetry={() => r.back()} onWaitlist={() => r.back()} onClose={() => r.push(st === 'confirmed' || st === 'waitlisted' ? '/mis-reservas' : '/reservar')} />
    </div>
  );
}
