'use client';
import { useParams } from 'next/navigation';
import { useAsync } from '@/hooks/useAsync';
import { getBonos, getClases, getPagos, getReservas } from '@/lib/data';
import { clasesPasadas } from '@/mocks/data';
import { fechaCorta, euros } from '@/lib/format';
import { PageHeader } from '@/components/shell/PageHeader';
import { CreditCard } from '@/components/domain/CreditCard';
import { ErrorState, Skeleton } from '@/components/ui/States';
import Link from 'next/link';

export default function DetalleBono() {
  const { creditId } = useParams<{ creditId: string }>();
  const { data, estado, reintentar } = useAsync(async () => { const [bonos, reservas, clases, pagos] = await Promise.all([getBonos(), getReservas(), getClases(), getPagos()]); const b = bonos.find((x) => x.id === creditId); return b ? { b, usos: reservas.filter((r) => r.bonoId === b.id).map((r) => ({ r, c: [...clases, ...clasesPasadas].find((c) => c.id === r.claseId) })), pago: pagos.find((p) => p.bonoId === b.id) } : null; }, (d) => !d);
  if (estado === 'loading') return <div className="px" style={{ paddingTop: 12, display: 'flex', flexDirection: 'column', gap: 12 }}><Skeleton h={30} w="50%" /><Skeleton h={110} r={16} /><Skeleton h={160} r={16} /></div>;
  if (!data) return <div className="px" style={{ paddingTop: 12 }}><ErrorState titulo="No encontramos este bono" onRetry={reintentar} /></div>;
  const { b, usos, pago } = data;
  return (
    <>
      <PageHeader titulo={b.nombre} back />
      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14 }}>
        <CreditCard bono={b} />
        <div className="card" style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12.5 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Comprado</span><b>{fechaCorta(b.compradoEn)} · {euros(b.precio)}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Usadas / total</span><b>{b.creditosUsados} / {b.creditosTotales}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Caducidad</span><b>{b.expiraEn ? fechaCorta(b.expiraEn) : 'Sin caducidad'}</b></div>
          {pago && <Link href={'/pagos/' + pago.id} style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)' }}>Ver el recibo →</Link>}
        </div>
        <section>
          <p className="t-label" style={{ margin: '0 0 8px' }}>Sesiones usadas</p>
          {usos.length === 0 ? <p className="t-meta">Todavía no has usado ninguna sesión de este bono.</p> : <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>{usos.map(({ r, c }) => <div key={r.id} className="card" style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 13px', fontSize: 12.5 }}><span style={{ fontWeight: 700 }}>{c?.nombre ?? 'Clase'}</span><span className="t-meta">{c ? fechaCorta(c.fecha) + ' · ' + c.hora : ''}</span></div>)}</div>}
        </section>
      </div>
    </>
  );
}
