'use client';
import { useAsync } from '@/hooks/useAsync';
import { getBonos } from '@/lib/data';
import { PageHeader } from '@/components/shell/PageHeader';
import { CreditCard } from '@/components/domain/CreditCard';
import { EmptyState, ErrorState, ListSkeleton, OfflineState } from '@/components/ui/States';
import Link from 'next/link';

export default function Bonos() {
  const { data, estado, reintentar } = useAsync(getBonos);
  const activos = data?.filter((b) => b.estado === 'activo') ?? []; const otros = data?.filter((b) => b.estado !== 'activo') ?? [];
  return (
    <>
      <PageHeader titulo="Bonos" sub="Tus sesiones y su caducidad" accion={<Link href="/pagos" className="btn btn--secondary btn--sm">Pagos</Link>} />
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 14 }}>
        {estado === 'loading' && <ListSkeleton n={2} h={96} />}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState />}
        {estado === 'empty' && <EmptyState icono="🎟" titulo="No tienes ningún bono" cuerpo="Habla con el estudio para activar uno; también puedes reservar clases sueltas." accion="Ver horario" href="/reservar" />}
        {data && (estado === 'ready') && (
          <>
            {activos.length === 0 && <EmptyState icono="🎟" titulo="Sin bono activo" cuerpo="Tus bonos anteriores están agotados o han caducado. Puedes reservar clases sueltas." accion="Ver horario" href="/reservar" />}
            {activos.map((b) => <CreditCard key={b.id} bono={b} />)}
            {otros.length > 0 && <p className="t-label" style={{ margin: '10px 0 0' }}>Anteriores</p>}
            {otros.map((b) => <CreditCard key={b.id} bono={b} />)}
          </>
        )}
      </div>
    </>
  );
}
