'use client';
import { useAsync } from '@/hooks/useAsync';
import { getPagos } from '@/lib/data';
import { PageHeader } from '@/components/shell/PageHeader';
import { PaymentItem } from '@/components/domain/PaymentItem';
import { EmptyState, ErrorState, ListSkeleton, OfflineState } from '@/components/ui/States';
export default function Pagos() {
  const { data, estado, reintentar } = useAsync(getPagos);
  return (
    <>
      <PageHeader titulo="Pagos" sub="Recibos y estado de cada cobro" back />
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 9, marginTop: 14 }}>
        {estado === 'loading' && <ListSkeleton n={3} h={66} />}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState cuerpo="Los recibos se mostrarán cuando vuelva la conexión." />}
        {estado === 'empty' && <EmptyState icono="🧾" titulo="Sin pagos todavía" cuerpo="Aquí aparecerán tus recibos." />}
        {estado === 'ready' && data?.map((p, i) => <PaymentItem key={p.id} p={p} delay={i * 55} />)}
      </div>
    </>
  );
}
