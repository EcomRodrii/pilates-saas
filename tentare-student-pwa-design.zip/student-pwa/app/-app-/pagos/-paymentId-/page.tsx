'use client';
import { useParams } from 'next/navigation';
import { useAsync } from '@/hooks/useAsync';
import { getPagos } from '@/lib/data';
import { euros, fechaLarga } from '@/lib/format';
import { studio } from '@/config/studio';
import { PageHeader } from '@/components/shell/PageHeader';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ErrorState, Skeleton } from '@/components/ui/States';
import { ESTADO_PAGO } from '@/components/domain/PaymentItem';
import { useToast } from '@/hooks/useToast';
import Link from 'next/link';

export default function DetallePago() {
  const { paymentId } = useParams<{ paymentId: string }>(); const { toast } = useToast();
  const { data, estado, reintentar } = useAsync(async () => (await getPagos()).find((p) => p.id === paymentId) ?? null, (d) => !d);
  if (estado === 'loading') return <div className="px" style={{ paddingTop: 12 }}><Skeleton h={30} w="40%" /><Skeleton h={220} r={20} style={{ marginTop: 14 }} /></div>;
  if (!data) return <div className="px" style={{ paddingTop: 12 }}><ErrorState titulo="No encontramos este pago" onRetry={reintentar} /></div>;
  const e = ESTADO_PAGO[data.estado];
  return (
    <>
      <PageHeader titulo="Recibo" back />
      <div className="px" style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 14, maxWidth: 520 }}>
        <div className="card a-pop" style={{ padding: '22px 18px', textAlign: 'center' }}>
          <Badge tone={e.tone}>{e.txt}</Badge>
          <p style={{ margin: '12px 0 0', fontSize: 34, fontWeight: 800, letterSpacing: '-.03em', textDecoration: data.estado === 'refunded' ? 'line-through' : 'none' }}>{euros(data.importe)}</p>
          <p style={{ margin: '4px 0 0', fontSize: 14, fontWeight: 700 }}>{data.concepto}</p>
          <p className="t-meta" style={{ marginTop: 3 }}>{fechaLarga(data.fecha)} · {data.metodo}</p>
          {data.estado === 'processing' && <p style={{ margin: '12px 0 0', fontSize: 12, color: 'var(--warning-foreground)', fontWeight: 700 }}>El banco todavía no ha confirmado el cobro. Te avisaremos.</p>}
          {data.estado === 'failed' && <p style={{ margin: '12px 0 0', fontSize: 12, color: 'var(--destructive-foreground)', fontWeight: 700 }}>El pago no se completó. No se ha hecho ningún cargo.</p>}
        </div>
        <div className="card" style={{ padding: '12px 14px', fontSize: 12.5, display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Emitido por</span><b>{studio.nombre}</b></div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted-foreground)' }}>Referencia</span><b className="t-mono">{data.id.toUpperCase()}</b></div>
          {data.bonoId && <Link href={'/bonos/' + data.bonoId} style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)' }}>Ver el bono →</Link>}
        </div>
        <Button variant="secondary" full onClick={() => toast('Descarga del recibo: pendiente de backend')}>Descargar recibo</Button>
        {data.estado === 'failed' && <Button full onClick={() => toast('Reintento de pago: pendiente de backend')}>Intentar el pago de nuevo</Button>}
      </div>
    </>
  );
}
