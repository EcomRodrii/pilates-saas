'use client';
import Link from 'next/link';
import { useAsync } from '@/hooks/useAsync';
import { useToast } from '@/hooks/useToast';
import { getBonos, getClases, getInstructoras, getReservas } from '@/lib/data';
import { studio } from '@/config/studio';
import { alumna } from '@/mocks/data';
import { fechaLarga, hoyISO, saludo } from '@/lib/format';
import { disponibilidad } from '@/lib/booking-machine';
import { NextClassCard } from '@/components/domain/NextClassCard';
import { ClassCard } from '@/components/domain/ClassCard';
import { CreditCard } from '@/components/domain/CreditCard';
import { EmptyState, ErrorState, OfflineState, Skeleton } from '@/components/ui/States';

export default function Inicio() {
  const { toast } = useToast();
  const { data, estado, reintentar } = useAsync(async () => {
    const [clases, reservas, bonos, inst] = await Promise.all([getClases(), getReservas(), getBonos(), getInstructoras()]);
    return { clases, reservas, bonos, inst };
  }, () => false);
  const hoy = hoyISO();
  const bonoActivo = data?.bonos.find((b) => b.estado === 'activo') ?? null;
  const proxima = data?.reservas.filter((r) => r.estado === 'confirmada').map((r) => ({ r, c: data.clases.find((c) => c.id === r.claseId)! })).filter((x) => x.c).sort((a, b) => (a.c.fecha + a.c.hora).localeCompare(b.c.fecha + b.c.hora))[0];
  const huecos = data?.clases.filter((c) => c.fecha === hoy && disponibilidad(c, data.reservas, studio.soportaListaEspera) !== 'reservada' && c.plazasLibres > 0).slice(0, 3) ?? [];

  return (
    <>
      {/* HERO fotográfico del kit */}
      <section style={{ position: 'relative', height: 250, marginTop: -56, overflow: 'hidden' }}>
        <img src={studio.fotoPortada} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 32%', animation: 'apKen 22s ease-in-out infinite' }} />
        <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'linear-gradient(185deg, rgba(8,8,8,.58), rgba(8,8,8,.18) 42%, rgba(8,8,8,.06) 58%, rgba(250,249,245,.35) 86%, var(--background))' }} />
        <div className="px" style={{ position: 'absolute', left: 0, right: 0, bottom: 14, color: '#FAF9F5' }}>
          <p className="t-label a-up" style={{ color: 'var(--accent-deep-muted)' }}>{studio.nombre} · {fechaLarga(hoy)}</p>
          <p className="a-up" style={{ margin: '8px 0 0', fontSize: 13, fontWeight: 700, color: 'rgba(250,249,245,.9)', animationDelay: '60ms' }}>{saludo(alumna.nombre)} 👋</p>
          <h1 className="a-up" style={{ margin: '2px 0 0', fontSize: 32, fontWeight: 800, letterSpacing: '-.035em', lineHeight: 1, animationDelay: '120ms' }}>¿Qué te apetece hoy?</h1>
        </div>
      </section>

      <div className="px grid-lg-2" style={{ display: 'flex', flexDirection: 'column', gap: 13, marginTop: 4 }}>
        {estado === 'loading' && <><Skeleton h={118} r={20} /><Skeleton h={62} r={16} /><Skeleton h={74} r={16} /><Skeleton h={74} r={16} /></>}
        {estado === 'error' && <ErrorState onRetry={reintentar} />}
        {estado === 'offline' && !data && <OfflineState />}
        {data && estado !== 'loading' && estado !== 'error' && (
          <>
            {proxima ? (
              <NextClassCard reserva={proxima.r} clase={proxima.c} instructora={data.inst.find((i) => i.id === proxima.c.instructoraId)} onCalendario={() => toast('Añadida a tu calendario ✓')} onComoLlegar={() => toast('Abriendo cómo llegar… 📍')} />
            ) : (
              <EmptyState icono="🧘" titulo="No tienes clases próximas" cuerpo={'Hay ' + huecos.length + ' clases hoy con plaza libre.'} accion="Ver el horario" href="/reservar" />
            )}
            {bonoActivo ? <CreditCard bono={bonoActivo} compacta /> : (
              <Link href="/bonos" className="card card--tap" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 15px' }}><p style={{ margin: 0, fontSize: 12.5, fontWeight: 700 }}>Sin bono activo</p><span style={{ fontSize: 11.5, fontWeight: 800, color: 'var(--accent)' }}>Ver bonos →</span></Link>
            )}
            <section>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 9 }}>
                <h2 className="t-h2">Huecos de hoy</h2>
                <Link href="/reservar" style={{ fontSize: 12, fontWeight: 800, color: 'var(--accent)' }}>Ver horario →</Link>
              </div>
              {huecos.length === 0 ? <EmptyState icono="📅" titulo="Hoy ya no quedan huecos" cuerpo="Mira mañana — suele haber más plazas por la mañana." accion="Ver mañana" href="/reservar" /> : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {huecos.map((c, i) => <ClassCard key={c.id} clase={c} instructora={data.inst.find((x) => x.id === c.instructoraId)} estado={disponibilidad(c, data.reservas, studio.soportaListaEspera)} conBono={!!bonoActivo} delay={i * 55} />)}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </>
  );
}
