# Tentare · Student PWA — Design + Frontend Reference Package

## 1. Qué es
La app de la **alumna** de un estudio de Pilates/Yoga que usa Tentare: reservar, ver sus clases, bonos, pagos, notificaciones y perfil. White-label: cada estudio la ve con su nombre, logo, foto y color. Instalable como PWA.

## 2. Qué NO es
No incluye nada de propietaria, administración, CRM, instructoras, marketing, automatizaciones, Tentare Network ni backoffice. No depende del antiguo `/portal` (borrado). Se reconstruye desde cero con este paquete como referencia.

## 3. Ejecutar
```bash
npm install
node scripts/rename-routes.mjs   # UNA vez: restaura (app) (auth) [id] — los ZIP no conservan esos nombres
npm run dev                      # http://localhost:3000
```
Rutas de auth: `/login`, `/registro`, `/recuperar-password`, `/verificar-email`. La raíz autenticada es `/`.
Para forzar estados en cualquier pantalla: `?state=loading|empty|error|offline`.
Para forzar el resultado del servidor al reservar: `/reservar/c1?outcome=full|conflict|duplicate|session-expired|error|waitlisted`.
Demo: login con contraseña `error` muestra el error de credenciales; el código de verificación es `4729`.

## 4. Estructura
```
app/            rutas (App Router) — (app)/ con AppShell, (auth)/ sin nav, offline/
components/
  shell/        AppShell, StudioHeader, BottomNavigation, PageHeader, OfflineBanner
  ui/           Button, Badge, Input, Sheet, ConfirmationDialog, States (Empty/Error/Offline/Skeleton)
  domain/       ClassCard, NextClassCard, CreditCard, InstructorCard, BookingButton, BookingStatus,
                BookingSummary, DateSelector, Calendar, NotificationItem, PaymentItem, ProfileSection
lib/            format.ts, theme.ts, booking-machine.ts, data/ (ADAPTADORES → backend)
hooks/          useAsync, useOnline, useToast, useDemoState
types/          modelo de dominio (Clase, Reserva, Bono, Pago, Notificacion, BookingState…)
config/         studio.ts (white-label)
mocks/          datos ficticios — SOLO para ver el diseño
styles/         tokens.css (variables semánticas) + globals.css (kit)
public/         assets/, icons/, manifest.webmanifest, sw.js
```

## 5. Rutas → ver STUDENT-PWA-HANDOFF.md §B.

## 6. Componentes → §C. Estilo: tokens CSS + clases del kit (`.card .btn .badge .pill .day .input`) + inline puntual. Sin Tailwind (el diseño original es inline-first; así se conserva 1:1).

## 7. Estados → §D y §G. Regla: **ninguna pantalla muestra éxito hasta que el adaptador devuelve confirmación**.

## 8. Responsive
Mobile-first 320–430. `.shell` centra a 560px (≥768: 640px; ≥1024: 1040px y `.grid-lg-2` divide en dos columnas las pantallas de detalle). Auth pasa a dos columnas en ≥768. Nav inferior siempre visible en móvil; en desktop sigue abajo (decisión: una sola navegación, la alumna usa mayormente el móvil).

## 9. White-label
`config/studio.ts` define nombre, logo, foto, contacto, política y `tema` (sobrescribe variables de `styles/tokens.css`). Ningún componente usa hex de marca: todo pasa por `--primary/--accent/--background…`. Los verdes de éxito/badges también son tokens (`--accent-soft`, `--accent-deep`).

## 10. Assets
`public/assets/` fotos de referencia (sustituir por las del estudio); `public/icons/` iconos PWA generados (sustituir por el icono del estudio). Fuentes vía `next/font/google` (Plus Jakarta Sans 400–800, IBM Plex Mono 400/500) — sin fichero local por licencia; si el estudio aporta fuente propia, cambiar `--font-sans`.

## 11. Animaciones → §I. Keyframes `ap*` conservados con sus nombres originales en globals.css.

## 12. Decisiones visuales documentadas
- La nav del prototipo era una cápsula flotante; aquí es barra full-width con `border-top` (mejor con teclado y safe-area). Misma tipografía/iconos.
- El pase QR se renderiza como grid decorativo: el QR real lo genera backend.
- Header transparente sobre héroes fotográficos (Inicio, detalle de clase).

## 13. Qué es mock
Todo `mocks/` y los retardos de `lib/data`. Los `?state=` y `?outcome=` son ayudas de revisión.

## 14. Qué debe conectar Claude Code
Solo `lib/data/index.ts` (mismas firmas), `config/studio.ts` (fetch por slug), sesión real (redirigir a `/login` si expira), `public/sw.js` (o el PWA plugin del repo), QR real, descarga de recibos, cambio de contraseña, valoración.

## 15. Qué NO debe cambiar Claude Code visualmente
Tokens, tipografía y escala, radios, sombras, keyframes, estructura del hero, badges de disponibilidad (3 estados + reservada/espera), sheet de reserva y celebración de confirmación, nav inferior, copy de estados (`lib/booking-machine.ts → COPY`).
