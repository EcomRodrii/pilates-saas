// ADAPTADORES DE DATOS. Los componentes solo importan de aquí.
// Hoy devuelven mocks con latencia simulada. Claude Code: reimplementar cada
// función contra el backend real de Tentare SIN cambiar sus firmas.
import * as mock from '@/mocks/data';
import type { Bono, BookingState, Clase, Instructora, Notificacion, Pago, Reserva } from '@/types';

const espera = (ms = 450) => new Promise((r) => setTimeout(r, ms));

export async function getClases(fecha?: string): Promise<Clase[]> { await espera(); return fecha ? mock.clases.filter((c) => c.fecha === fecha) : mock.clases; }
export async function getClase(id: string): Promise<Clase | null> { await espera(300); return [...mock.clases, ...mock.clasesPasadas].find((c) => c.id === id) ?? null; }
export async function getInstructoras(): Promise<Instructora[]> { await espera(200); return mock.instructoras; }
export async function getReservas(): Promise<Reserva[]> { await espera(); return mock.reservas; }
export async function getBonos(): Promise<Bono[]> { await espera(); return mock.bonos; }
export async function getPagos(): Promise<Pago[]> { await espera(); return mock.pagos; }
export async function getNotificaciones(): Promise<Notificacion[]> { await espera(); return mock.notificaciones; }

/**
 * Confirmar reserva. El resultado SIEMPRE viene del "servidor": la UI nunca
 * muestra éxito antes de recibir 'confirmed' | 'waitlisted'.
 * En mock, `outcome` fuerza un escenario para poder ver cada estado.
 */
export type BookingOutcome = Extract<BookingState, 'confirmed' | 'waitlisted' | 'full' | 'conflict' | 'duplicate' | 'session-expired' | 'error'>;
export async function confirmarReserva(claseId: string, outcome?: BookingOutcome): Promise<{ state: BookingOutcome; reservaId?: string }> {
  await espera(1100);
  if (outcome) return { state: outcome, reservaId: outcome === 'confirmed' ? 'r-new' : undefined };
  const c = mock.clases.find((x) => x.id === claseId);
  if (!c) return { state: 'error' };
  if (c.plazasLibres === 0) return { state: 'waitlisted' };
  return { state: 'confirmed', reservaId: 'r-' + claseId };
}

export async function cancelarReserva(reservaId: string, fail = false): Promise<{ ok: boolean; devuelveCredito: boolean }> {
  await espera(900);
  if (fail) return { ok: false, devuelveCredito: false };
  return { ok: true, devuelveCredito: true };
}
