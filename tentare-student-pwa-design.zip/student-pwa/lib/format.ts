const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const DIAS_C = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
export const hoyISO = () => new Date().toISOString().slice(0, 10);
export function addDias(iso: string, n: number) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); }
export function etiquetaDia(iso: string): string { const h = hoyISO(); if (iso === h) return 'Hoy'; if (iso === addDias(h, 1)) return 'Mañana'; const d = new Date(iso + 'T00:00:00'); return DIAS_C[d.getDay()][0].toUpperCase() + DIAS_C[d.getDay()].slice(1) + ' ' + d.getDate(); }
export function fechaCorta(iso: string): string { const d = new Date(iso + 'T00:00:00'); return DIAS_C[d.getDay()] + ' ' + d.getDate() + ' ' + MESES[d.getMonth()]; }
export function fechaLarga(iso: string): string { const d = new Date(iso + 'T00:00:00'); return DIAS[d.getDay()] + ' ' + d.getDate() + ' de ' + ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'][d.getMonth()]; }
export function saludo(nombre: string) { const h = new Date().getHours(); return (h < 13 ? 'Buenos días' : h < 20 ? 'Buenas tardes' : 'Buenas noches') + ', ' + nombre; }
export function euros(n: number) { return n.toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' €'; }
export function relativo(isoDateTime: string) { const ms = Date.now() - new Date(isoDateTime).getTime(); const m = Math.round(ms / 60000); if (m < 60) return 'hace ' + Math.max(1, m) + ' min'; const h = Math.round(m / 60); if (h < 24) return 'hace ' + h + ' h'; const d = Math.round(h / 24); return d === 1 ? 'ayer' : 'hace ' + d + ' días'; }
