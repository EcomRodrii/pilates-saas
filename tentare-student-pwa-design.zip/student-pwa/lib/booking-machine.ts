import type { BookingState, Clase, Disponibilidad, Reserva } from '@/types';

/** Disponibilidad visible de una clase para ESTA alumna. */
export function disponibilidad(c: Clase, reservas: Reserva[], soportaEspera: boolean): Disponibilidad {
  const mia = reservas.find((r) => r.claseId === c.id && (r.estado === 'confirmada' || r.estado === 'en-espera'));
  if (mia?.estado === 'confirmada') return 'reservada';
  if (mia?.estado === 'en-espera') return 'lista-espera';
  if (c.plazasLibres <= 0) return soportaEspera ? 'completa' : 'no-disponible';
  if (c.plazasLibres <= 2) return 'pocas';
  return 'disponible';
}

/** ¿Se puede cancelar sin perder el crédito? (política del estudio en horas) */
export function cancelable(c: Clase, horasPolitica: number) {
  const inicio = new Date(c.fecha + 'T' + c.hora + ':00').getTime();
  const restan = (inicio - Date.now()) / 36e5;
  return { puede: restan > 0, devuelveCredito: restan >= horasPolitica, horasRestantes: Math.max(0, Math.floor(restan)) };
}

/** Transiciones válidas de la máquina de reserva. */
export const TRANSICIONES: Record<BookingState, BookingState[]> = {
  idle: ['reviewing'],
  reviewing: ['submitting', 'idle', 'offline'],
  submitting: ['confirmed', 'waitlisted', 'full', 'conflict', 'duplicate', 'session-expired', 'error', 'offline'],
  confirmed: [], waitlisted: [],
  full: ['reviewing', 'idle'], conflict: ['idle'], duplicate: ['idle'],
  'session-expired': ['idle'], offline: ['reviewing'], error: ['reviewing', 'idle'],
};

export const COPY: Record<Exclude<BookingState, 'idle' | 'reviewing' | 'submitting'>, { titulo: string; cuerpo: string; tono: 'ok' | 'warn' | 'error' }> = {
  confirmed: { titulo: 'Reserva confirmada', cuerpo: 'Te esperamos. Te avisamos el día antes.', tono: 'ok' },
  waitlisted: { titulo: 'Estás en la lista de espera', cuerpo: 'Te avisamos al momento si se libera una plaza.', tono: 'warn' },
  full: { titulo: 'Se ha llenado mientras reservabas', cuerpo: 'Otra alumna ha cogido la última plaza. Puedes apuntarte a la lista de espera o elegir otra hora.', tono: 'warn' },
  conflict: { titulo: 'Ya tienes una clase a esa hora', cuerpo: 'Coincide con otra reserva tuya. Cancela una de las dos para continuar.', tono: 'warn' },
  duplicate: { titulo: 'Ya estabas apuntada', cuerpo: 'Esta clase ya está en tus reservas. No se ha creado ninguna nueva.', tono: 'warn' },
  'session-expired': { titulo: 'Tu sesión ha caducado', cuerpo: 'Vuelve a iniciar sesión para reservar. No se ha hecho ningún cargo.', tono: 'error' },
  offline: { titulo: 'Sin conexión', cuerpo: 'No podemos confirmar la reserva sin conexión. Inténtalo cuando vuelvas a tener red — no se ha hecho ningún cargo.', tono: 'error' },
  error: { titulo: 'Algo no ha salido como esperábamos', cuerpo: 'Tu reserva no se ha completado y no se ha usado ninguna sesión. Inténtalo de nuevo.', tono: 'error' },
};
