// Aplica el tema white-label del estudio: escribe las CSS vars de config.tema
// sobre :root. Se llama una vez desde AppShell / layout de auth.
import type { StudioConfig } from '@/types';
export function aplicarTema(tema: StudioConfig['tema']) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  Object.entries(tema).forEach(([k, v]) => root.style.setProperty(k, v));
}
export function iniciales(nombre: string) { return nombre.split(/\s+/).map((p) => p[0]).join('').slice(0, 2).toUpperCase(); }
