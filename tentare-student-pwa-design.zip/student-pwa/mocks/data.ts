import type { Alumna, Bono, Clase, Instructora, Notificacion, Pago, Reserva } from '@/types';

const hoy = new Date(); const d = (n: number) => { const x = new Date(hoy); x.setDate(x.getDate() + n); return x.toISOString().slice(0, 10); };

export const alumna: Alumna = { id: 'u1', nombre: 'Laura', apellidos: 'Martín', email: 'laura@example.com', telefono: '+34 600 111 222', fotoUrl: null };

export const instructoras: Instructora[] = [
  { id: 'i1', nombre: 'Marta G.', iniciales: 'MG', fotoUrl: '/assets/foto-pilates.jpg', especialidades: ['Reformer', 'Prenatal'], rating: 4.9, bio: 'Formada en Balanced Body. Reformer clínico y prenatal, grupos pequeños y correcciones constantes.' },
  { id: 'i2', nombre: 'Lucía R.', iniciales: 'LR', fotoUrl: '/assets/foto-clase.webp', especialidades: ['Reformer', 'Barre'], rating: 5.0 },
  { id: 'i3', nombre: 'Carmen V.', iniciales: 'CV', fotoUrl: '/assets/foto-hero.jpg', especialidades: ['Yoga Flow', 'Yin'], rating: 4.8 },
];

const base = { disciplina: 'Pilates' as const, sala: 'Sala Reformer', capacidad: 6, fotoUrl: '/assets/foto-reformer.webp' };
export const clases: Clase[] = [
  { ...base, id: 'c1', fecha: d(0), hora: '18:00', duracionMin: 50, nombre: 'Reformer · nivel medio', tipo: 'Reformer', nivel: 'Medio', instructoraId: 'i1', plazasLibres: 5, precioSuelto: 18 },
  { ...base, id: 'c2', fecha: d(0), hora: '19:30', duracionMin: 50, nombre: 'Reformer · intenso', tipo: 'Reformer', nivel: 'Avanzado', instructoraId: 'i1', plazasLibres: 2, precioSuelto: 18 },
  { ...base, id: 'c3', fecha: d(0), hora: '20:30', duracionMin: 50, nombre: 'Reformer · suave', tipo: 'Reformer', nivel: 'Iniciación', instructoraId: 'i2', plazasLibres: 0, precioSuelto: 18 },
  { ...base, id: 'c4', fecha: d(0), hora: '12:30', duracionMin: 60, nombre: 'Yoga Flow', tipo: 'Yoga Flow', disciplina: 'Yoga', sala: 'Sala Mat', capacidad: 12, instructoraId: 'i3', plazasLibres: 7, precioSuelto: 12, nivel: 'Todos', fotoUrl: '/assets/foto-hero.jpg' },
  { ...base, id: 'c5', fecha: d(1), hora: '09:00', duracionMin: 50, nombre: 'Reformer · despertar', tipo: 'Reformer', nivel: 'Todos', instructoraId: 'i1', plazasLibres: 4, precioSuelto: 18 },
  { ...base, id: 'c6', fecha: d(1), hora: '17:30', duracionMin: 60, nombre: 'Yin Yoga', tipo: 'Yin', disciplina: 'Yoga', sala: 'Sala Mat', capacidad: 12, instructoraId: 'i3', plazasLibres: 9, precioSuelto: 12, nivel: 'Todos', fotoUrl: '/assets/foto-clase.webp' },
  { ...base, id: 'c7', fecha: d(1), hora: '18:00', duracionMin: 50, nombre: 'Reformer · prenatal', tipo: 'Reformer', nivel: 'Todos', instructoraId: 'i1', plazasLibres: 3, precioSuelto: 18 },
  { ...base, id: 'c8', fecha: d(2), hora: '09:00', duracionMin: 50, nombre: 'Reformer · nivel medio', tipo: 'Reformer', nivel: 'Medio', instructoraId: 'i2', plazasLibres: 5, precioSuelto: 18 },
  { ...base, id: 'c9', fecha: d(2), hora: '19:30', duracionMin: 50, nombre: 'Reformer · intenso', tipo: 'Reformer', nivel: 'Avanzado', instructoraId: 'i1', plazasLibres: 6, precioSuelto: 18 },
  { ...base, id: 'c10', fecha: d(3), hora: '18:00', duracionMin: 45, nombre: 'Mat · core y movilidad', tipo: 'Mat', sala: 'Sala Mat', capacidad: 10, nivel: 'Todos', instructoraId: 'i2', plazasLibres: 6, precioSuelto: 14, fotoUrl: '/assets/foto-estudio.webp' },
];

export const reservas: Reserva[] = [
  { id: 'r1', claseId: 'c5', alumnaId: 'u1', estado: 'confirmada', creadaEn: d(-1) + 'T10:00:00', pagadaCon: 'bono', bonoId: 'b1' },
  { id: 'r0', claseId: 'c-past-1', alumnaId: 'u1', estado: 'asistida', creadaEn: d(-4) + 'T10:00:00', pagadaCon: 'bono', bonoId: 'b1' },
];
/** Clases pasadas para el historial (no aparecen en el horario). */
export const clasesPasadas: Clase[] = [
  { ...base, id: 'c-past-1', fecha: d(-3), hora: '19:30', duracionMin: 50, nombre: 'Reformer · intenso', tipo: 'Reformer', nivel: 'Avanzado', instructoraId: 'i1', plazasLibres: 0, precioSuelto: 18 },
];

export const bonos: Bono[] = [
  { id: 'b1', nombre: 'Bono 5 sesiones', creditosTotales: 5, creditosUsados: 2, compradoEn: d(-20), expiraEn: d(40), estado: 'activo', precio: 80 },
  { id: 'b0', nombre: 'Bono 10 sesiones', creditosTotales: 10, creditosUsados: 10, compradoEn: d(-90), expiraEn: d(-10), estado: 'agotado', precio: 150 },
];

export const pagos: Pago[] = [
  { id: 'p1', concepto: 'Bono 5 sesiones', importe: 80, fecha: d(-20), estado: 'success', metodo: 'Apple Pay', bonoId: 'b1' },
  { id: 'p0', concepto: 'Bono 10 sesiones', importe: 150, fecha: d(-90), estado: 'success', metodo: 'Tarjeta ···· 4242', bonoId: 'b0' },
  { id: 'p2', concepto: 'Clase suelta · Yoga Flow', importe: 12, fecha: d(-45), estado: 'refunded', metodo: 'Tarjeta ···· 4242' },
];

export const notificaciones: Notificacion[] = [
  { id: 'n1', tipo: 'plaza-liberada', titulo: '¡Se ha liberado una plaza!', cuerpo: 'Reformer · suave · hoy 20:30 — reserva antes de que vuele.', fecha: d(0) + 'T11:20:00', leida: false, enlace: '/reservar/c3' },
  { id: 'n2', tipo: 'recordatorio', titulo: 'Mañana tienes clase', cuerpo: 'Reformer · despertar · 09:00 con Marta G. Llega 10 min antes.', fecha: d(0) + 'T09:00:00', leida: false, enlace: '/mis-reservas/r1' },
  { id: 'n3', tipo: 'bono', titulo: 'Tu bono caduca pronto', cuerpo: 'Te quedan 3 sesiones y caduca en 40 días.', fecha: d(-1) + 'T18:00:00', leida: true, enlace: '/bonos/b1' },
  { id: 'n4', tipo: 'estudio', titulo: 'Horario de septiembre publicado', cuerpo: 'Nuevas clases de Yin Yoga los martes.', fecha: d(-3) + 'T12:00:00', leida: true },
];
