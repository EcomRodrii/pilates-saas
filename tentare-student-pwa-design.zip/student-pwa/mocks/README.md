# mocks/
Datos FICTICIOS solo para visualizar el diseño. Nada de aquí es arquitectura.
Claude Code: sustituir `lib/data/*` (los adaptadores) por llamadas al backend
real de Tentare; los componentes solo conocen los tipos de `types/`.
